export interface MenuItem {
  id: string;
  name: string;
  description?: string;
  price?: string;
  priceIndividual?: string;
  priceLarge?: string;
  image?: string;
  featured?: boolean;
}

export interface MenuCategory {
  id: string;
  title: string;
  subtitle?: string;
  note?: string;
  bannerImage: string;
  items: MenuItem[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  caption: string;
  image: string;
  span?: 'wide' | 'tall' | 'standard';
}

export const RESTAURANT_INFO = {
  name: 'Trattoria 1958',
  tagline: 'Uma tradição italiana no coração do Rio de Janeiro.',
  addressLine1: 'Rua Senador Dantas, 23 — Loja B',
  addressLine2: 'Centro, Rio de Janeiro — RJ',
  cep: 'CEP: 20031-204',
  fullAddress: 'Rua Senador Dantas, 23 — Loja B, Centro, Rio de Janeiro — RJ, CEP: 20031-204',
  phoneDisplay: '+55 21 2220-2783',
  phoneHref: 'tel:+552122202783',
  whatsappDisplay: '(21) 2220-2783',
  whatsappNumber: '552122202783',
  whatsappUrl: 'https://wa.me/552122202783',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=Rua+Senador+Dantas+23+Centro+Rio+de+Janeiro+RJ+20031-204',
  mapsEmbedUrl:
    'https://maps.google.com/maps?q=Rua%20Senador%20Dantas%2C%2023%20-%20Centro%2C%20Rio%20de%20Janeiro%20-%20RJ%2C%2020031-204&t=&z=16&ie=UTF8&iwloc=&output=embed',
  rating: '4,6',
  reviewCount: '1.635',
  categoryLabel: 'Restaurante italiano',
  priceRange: 'R$ 80–140 por pessoa',
};

export const OPENING_HOURS = [
  { day: 'Segunda-feira', hours: '11h30 às 22h30', isOpen: true },
  { day: 'Terça-feira', hours: '11h30 às 22h30', isOpen: true },
  { day: 'Quarta-feira', hours: '11h30 às 22h30', isOpen: true },
  { day: 'Quinta-feira', hours: '11h30 às 22h30', isOpen: true },
  { day: 'Sexta-feira', hours: '11h30 às 22h30', isOpen: true },
  { day: 'Sábado', hours: 'Fechado', isOpen: false },
  { day: 'Domingo', hours: 'Fechado', isOpen: false },
];

export const MENU_CATEGORIES: MenuCategory[] = [
  {
    id: 'entradas',
    title: 'Entradas',
    subtitle: 'Antepastos clássicos, pães artesanais e preparos saídos do forno a lenha',
    bannerImage:
      'https://images.pexels.com/photos/35438980/pexels-photo-35438980.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'couvert-da-casa',
        name: 'Couvert da Casa',
        price: 'R$ 39',
        description:
          'Cesta de pães artesanais e torradas, servida com antepastos do dia como sardela, pasta de queijo e caponata.',
        image:
          'https://images.pexels.com/photos/4087611/pexels-photo-4087611.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
      {
        id: 'queijo-brie',
        name: 'Queijo Brie',
        price: 'R$ 55',
        description:
          'Queijo tipo francês, aquecido no forno a lenha ao azeite de ervas finas e tomate cereja.',
      },
      {
        id: 'burrata-alla-trattoria',
        name: 'Burrata alla Trattoria',
        price: 'R$ 65',
        description:
          'Queijo italiano, servido com tomates cerejas e pesto de manjericão. Acompanha cesta de torrada.',
        image:
          'https://images.pexels.com/photos/19252766/pexels-photo-19252766.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'carpaccio-de-carne',
        name: 'Carpaccio de Carne',
        price: 'R$ 55',
        description:
          'Finíssimas fatias de carne, servidas com folhas de rúcula, queijo parmesão, molho especial da casa e torradas.',
      },
      {
        id: 'funghi-freschi-gratinati',
        name: 'Funghi Freschi Gratinati nel Forno a Legna',
        price: 'R$ 46',
        description:
          'Seis cogumelos recheados de creme de queijo gorgonzola e azeite temperado, levados ao forno para gratinar.',
      },
      {
        id: 'tagliere-di-salumi',
        name: 'Tagliere di Salumi e Formaggi',
        price: 'R$ 59',
        description:
          'Seleção especial de queijos e frios italianos, acompanhados de antepastos e pães artesanais.',
        image:
          'https://images.pexels.com/photos/35438980/pexels-photo-35438980.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'bruschetta-napolitana',
        name: 'Bruschetta Napolitana',
        price: 'R$ 16',
        description:
          'Pão italiano tostado com azeite extra virgem, servido com tomates picados e manjericão.',
        image:
          'https://images.pexels.com/photos/15879697/pexels-photo-15879697.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
    ],
  },
  {
    id: 'pizzas-especiais',
    title: 'Pizzas Especiais',
    subtitle: 'Massa artesanal de fermentação cuidadosa com combinações exclusivas da casa',
    note: 'Todas as pizzas possuem opção individual e grande.',
    bannerImage:
      'https://images.pexels.com/photos/31357689/pexels-photo-31357689.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'pizza-parma',
        name: 'Parma',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 128',
        description:
          'Molho de tomate, mozzarella, abobrinha, tomate cereja, finíssimas fatias de parma, rúcula, parmesão e orégano.',
        image:
          'https://images.pexels.com/photos/31357689/pexels-photo-31357689.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'pizza-carciofi',
        name: 'Carciofi',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 128',
        description:
          'Molho de tomate, mozzarella de búfala, espinafre refogado, coração de alcachofra, lascas de bacon e alho frito.',
      },
      {
        id: 'pizza-gamberi',
        name: 'Gamberi',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 128',
        description:
          'Molho de tomate, mozzarella e camarões salteados com tomate cereja e temperos especiais, alho-poró, catupiry e orégano.',
      },
      {
        id: 'pizza-stracciatella',
        name: 'Stracciatella',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 132',
        description:
          'Molho de tomate, mozzarella de búfala, tomate confit, palmito, manjericão, orégano e azeite de trufa.',
        image:
          'https://images.pexels.com/photos/19252766/pexels-photo-19252766.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
      {
        id: 'pizza-trattoria-1958',
        name: 'Trattoria 1958',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 128',
        description:
          'Molho de tomate, mozzarella de búfala, parma crocante, pesto de manjericão, raspas de limão siciliano, rúcula e orégano.',
        image: '/images/hero-trattoria.jpg',
        featured: true,
      },
      {
        id: 'pizza-capriciosa',
        name: 'Capriciosa',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 128',
        description:
          'Molho de tomate, mozzarella de búfala, tomate cereja assado, rúcula e lascas de bacon crocante.',
      },
      {
        id: 'pizza-prosciutto-cotto-funghi',
        name: 'Prosciutto Cotto e Funghi',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, presunto, cogumelo paris fresco salteado no alecrim e gorgonzola.',
      },
      {
        id: 'pizza-quattro-formaggi',
        name: 'Quattro Formaggi',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 128',
        description:
          'Molho de tomate, mozzarella, parmesão, gorgonzola e catupiry.',
      },
    ],
  },
  {
    id: 'pizzas-tradicionais',
    title: 'Pizzas Tradicionais',
    subtitle: 'Receitas consagradas da tradição pizzaiola italiana',
    note: 'Todas as pizzas possuem opção individual e grande.',
    bannerImage:
      'https://images.pexels.com/photos/19260826/pexels-photo-19260826.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'pizza-dnapole',
        name: "D'napole",
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, cogumelos portobello salteados, tomate seco e rúcula. Finalizado com mozzarella de búfala.',
        image:
          'https://images.pexels.com/photos/37604434/pexels-photo-37604434.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
      {
        id: 'pizza-toscana',
        name: 'Toscana',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, linguiça toscana, cebola roxa, azeitona preta, orégano e ovo de codorna gratinado.',
      },
      {
        id: 'pizza-frango-catupiry',
        name: 'Frango com Catupiry',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, frango desfiado e levemente temperado. Servidas com camadas de catupiry e orégano.',
      },
      {
        id: 'pizza-peperoni',
        name: 'Peperoni',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, peperoni, manjericão e orégano.',
      },
      {
        id: 'pizza-marguerita',
        name: 'Marguerita',
        priceIndividual: 'R$ 55',
        priceLarge: 'R$ 108',
        description:
          'Molho de tomate, mozzarella, fatias de tomate e manjericão.',
        image:
          'https://images.pexels.com/photos/19260826/pexels-photo-19260826.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'pizza-calabresa',
        name: 'Calabresa',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, linguiça calabresa especial e cebola roxa.',
      },
      {
        id: 'pizza-calabresa-speciale',
        name: 'Calabresa Speciale',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho especial, mozzarella, calabresa especial, ramos de erva-doce e finalizada com mel picante.',
      },
      {
        id: 'pizza-portuguesa',
        name: 'Portuguesa',
        priceIndividual: 'R$ 56',
        priceLarge: 'R$ 118',
        description:
          'Molho especial, mozzarella, calabresa, presunto, creme de ovos com parmesão, alho-poró e orégano.',
      },
      {
        id: 'pizza-scarola-pancetta',
        name: 'Scarola e Pancetta',
        priceIndividual: 'R$ 59',
        priceLarge: 'R$ 118',
        description:
          'Molho de tomate, mozzarella, escarola refogada, bacon fatiado, alho em lâminas e ovo caipira frito.',
      },
    ],
  },
  {
    id: 'carnes',
    title: 'Carnes',
    subtitle: 'Cortes nobres preparados com técnica italiana e acompanhamentos artesanais',
    bannerImage:
      'https://images.pexels.com/photos/33673982/pexels-photo-33673982.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'tornedor-caccio-e-pepe',
        name: 'Tornedor al Caccio e Pepe',
        price: 'R$ 96',
        description:
          'Corte alto do filé mignon, ao ponto para mal, crosta de cogumelo, servido com risoto de queijo parmesão com pimenta do reino.',
        image:
          'https://images.pexels.com/photos/33673982/pexels-photo-33673982.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'stinco-di-agnello',
        name: 'Stinco di Agnello',
        price: 'R$ 96',
        description:
          'Stinco de cordeiro marinado em ervas finas e cozido lentamente em baixa temperatura, servido em seu próprio molho. Acompanha gnocchi artesanal de batata, grelhado na manteiga com cogumelos.',
        image:
          'https://images.pexels.com/photos/13322847/pexels-photo-13322847.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'tagliata-di-manzo',
        name: 'Tagliata di Manzo',
        price: 'R$ 89',
        description:
          'Baby beef fatiado, servido ao ponto para mal, servido com Caramelli artesanal recheado com seleção de queijos e finalizada com creme de parmesão.',
      },
      {
        id: 'file-mignon-oswaldo-aranha',
        name: 'Filé Mignon à Oswaldo Aranha',
        price: 'R$ 92',
        description:
          'Filé mignon grelhado, alho frito, acompanha arroz, farofa e batatas portuguesas.',
      },
      {
        id: 'file-a-parmegiana',
        name: 'Filé à Parmegiana',
        price: 'R$ 89',
        description:
          'Carne empanada, coberta com mozzarella, gratinada, servida com purê de batata e molho de tomate, gratinado no nosso forno a lenha.',
      },
      {
        id: 'file-a-milanesa',
        name: 'Filé à Milanesa',
        price: 'R$ 84',
        description:
          'Filé mignon empanado com farinha panko, acompanha fettuccine artesanal ao molho de queijos.',
      },
      {
        id: 'picadinho-carioca',
        name: 'Picadinho Carioca',
        price: 'R$ 78',
        description:
          'Filé mignon cortado na ponta da faca, servido ao molho madeira, acompanha arroz, ovo estrelado, banana à milanesa e batata frita.',
      },
    ],
  },
  {
    id: 'saladas',
    title: 'Saladas',
    subtitle: 'Folhas frescas, queijos selecionados e molhos preparados na casa',
    bannerImage:
      'https://images.pexels.com/photos/34307857/pexels-photo-34307857.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'salada-salmao-grelhado',
        name: 'Salada de Salmão Grelhado',
        price: 'R$ 59',
        description:
          'Mix de folhas, cubos de salmão grelhado, crouton artesanal, tomate cereja, parmesão e vinagrete cítrico.',
        image:
          'https://images.pexels.com/photos/5863631/pexels-photo-5863631.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
      {
        id: 'insalata-di-parma',
        name: 'Insalata di Parma',
        price: 'R$ 59',
        description:
          'Mix de folhas, lascas de presunto de parma, molho mel com mostarda, mozzarella de búfala e tomate cereja.',
      },
      {
        id: 'caesar-salad',
        name: 'Caesar Salad',
        price: 'R$ 55',
        description:
          'Alface americana, peito de frango grelhado e fatiado, crouton artesanal, bacon crocante e parmesão.',
      },
      {
        id: 'salada-caprese',
        name: 'Salada Caprese',
        price: 'R$ 49',
        description:
          'Fatias de tomate, mozzarella de búfala e pesto de manjericão.',
        image:
          'https://images.pexels.com/photos/34307857/pexels-photo-34307857.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
    ],
  },
  {
    id: 'risotos',
    title: 'Risotos',
    subtitle: 'Arroz arbóreo preparado lentamente com ingredientes nobres',
    bannerImage:
      'https://images.pexels.com/photos/7491887/pexels-photo-7491887.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'risoto-gamberi',
        name: 'Gamberi',
        price: 'R$ 94',
        description:
          'Arroz arbóreo, camarões frescos salteados no alho e finalizados com creme de mascarpone e raspas de limão siciliano.',
        image:
          'https://images.pexels.com/photos/31779537/pexels-photo-31779537.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'risoto-polpo-panceta',
        name: 'Polpo e Panceta',
        price: 'R$ 94',
        description:
          'Tentáculos de polvo grelhados, servidos com arroz arbóreo, bacon, azeitonas pretas, tomates e finalizado com pangrattato com ervas.',
      },
      {
        id: 'risoto-filletto-ai-funghi',
        name: 'Filletto ai Funghi',
        price: 'R$ 85',
        description:
          'Arroz arbóreo com cubos de filé mignon e ragú de cogumelos. Finalizado com parmesão, manteiga e ervas.',
        image:
          'https://images.pexels.com/photos/5638527/pexels-photo-5638527.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
      {
        id: 'risoto-al-tartufo',
        name: 'Risoto al Tartufo',
        price: 'R$ 74',
        description:
          'Arroz arbóreo com cogumelos frescos selecionados, alho-poró e tomate cereja. Finalizados com azeite de trufa e ervas.',
        image:
          'https://images.pexels.com/photos/7491887/pexels-photo-7491887.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
      },
    ],
  },
  {
    id: 'peixes',
    title: 'Peixes',
    subtitle: 'Frescor do mar e receitas clássicas italianas',
    bannerImage:
      'https://images.pexels.com/photos/8696564/pexels-photo-8696564.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'pesce-del-giorno-alla-romana',
        name: 'Pesce del Giorno alla Romana',
        price: 'R$ 92',
        description:
          'Filé de peixe do dia, assado com ervas, vinho branco e azeite, servido com batatas ao murro, brócolis, azeitonas e tomates assados.',
      },
      {
        id: 'salmone-al-limone',
        name: 'Salmone al Limone',
        price: 'R$ 94',
        description:
          'Filé de salmão assado, servido com nosso delicioso risoto de limão siciliano.',
        image:
          'https://images.pexels.com/photos/5863631/pexels-photo-5863631.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'pirarucu-con-insalata',
        name: 'Pirarucu con Insalata di Stagione',
        price: 'R$ 88',
        description:
          'Nosso bacalhau da Amazônia com carne alta e suculenta, servido com nossa seleção de folhas, tomates, palmito e gremolata de limão siciliano.',
      },
    ],
  },
  {
    id: 'aves',
    title: 'Aves',
    subtitle: 'Preparos clássicos servidos com acompanhamentos artesanais',
    bannerImage:
      'https://images.pexels.com/photos/1639563/pexels-photo-1639563.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'frango-a-parmegiana',
        name: 'Frango à Parmegiana',
        price: 'R$ 76',
        description:
          'Filé de frango empanado, coberto com mozzarella e gratinado. Servido com molho de tomate e purê de batata.',
      },
      {
        id: 'pollo-alla-griglia',
        name: 'Pollo alla Griglia',
        price: 'R$ 74',
        description:
          'Peito de frango grelhado, servido com vegetais selecionados ao azeite de ervas e finalizado com mozzarella líquida.',
      },
    ],
  },
  {
    id: 'pizzas-doces',
    title: 'Pizzas Doces',
    subtitle: 'Massa fininha e crocante para finalizar a refeição',
    note: 'Todas as pizzas possuem opção individual e grande.',
    bannerImage:
      'https://images.pexels.com/photos/21792440/pexels-photo-21792440.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'pizza-nutella-morangos',
        name: 'Nutella com Morangos',
        priceIndividual: 'R$ 55',
        priceLarge: 'R$ 98',
        description:
          'Massa fininha e crocante, creme de avelã Nutella e morangos laminados.',
      },
      {
        id: 'pizza-banana-nevada',
        name: 'Banana Nevada',
        priceIndividual: 'R$ 49',
        priceLarge: 'R$ 95',
        description:
          'Massa fina, mozzarella, bananas em fatias, chocolate branco gratinado e polvilhado com canela.',
      },
    ],
  },
  {
    id: 'sobremesas',
    title: 'Sobremesas',
    subtitle: 'Doces clássicos da confeitaria italiana preparados na casa',
    bannerImage: '/images/tiramisu-espresso.jpg',
    items: [
      {
        id: 'tiramisu',
        name: 'Tiramisù',
        price: 'R$ 29',
        description:
          'Creme leve de gemas com mascarpone, intercalado com biscoitos embebidos no café e sambuca.',
        image: '/images/tiramisu-espresso.jpg',
        featured: true,
      },
      {
        id: 'torta-di-cioccolato',
        name: 'Torta di Cioccolato',
        price: 'R$ 29',
        description:
          'Bolo de chocolate meio amargo, com chantilly de mascarpone e creme inglês, protegido por uma delicada esfera de chocolate, calda quente de chocolate que, ao ser derramada, revela o interior da sobremesa.',
      },
      {
        id: 'cannoli-pistachio-frutti-di-bosco',
        name: 'Cannoli de pistachio e frutti di Bosco',
        price: 'R$ 24',
        description:
          'Canudo crocante artesanal com recheio de pistache, crocante de castanhas e um creme liso de frutas vermelhas.',
        image:
          'https://images.pexels.com/photos/7474117/pexels-photo-7474117.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        featured: true,
      },
      {
        id: 'crema-soffiata-alla-nocciola',
        name: 'Crema Soffiata alla Nocciola',
        price: 'R$ 24',
        description:
          'Torta recheada com doce de leite acompanhada de creme aerado de avelã e chocolate branco.',
      },
      {
        id: 'mini-calzone-split',
        name: 'Mini Calzone Split',
        price: 'R$ 29',
        description:
          'Massa napoletana recheada com banana caramelizada, sorvete de creme e chantilly e finalizada com farofa de nozes.',
      },
      {
        id: 'pudim-de-leite-condensado',
        name: 'Pudim de Leite Condensado',
        price: 'R$ 18',
      },
    ],
  },
  {
    id: 'bebidas-nao-alcoolicas',
    title: 'Bebidas Não Alcoólicas',
    subtitle: 'Águas importadas e nacionais, sodas artesanais, sucos naturais e café expresso',
    bannerImage:
      'https://images.pexels.com/photos/28482524/pexels-photo-28482524.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    items: [
      {
        id: 'agua-san-pellegrino',
        name: 'Água San Pellegrino 505 ml',
        price: 'R$ 29',
      },
      {
        id: 'agua-mineral-prata',
        name: 'Água Mineral Prata 370 ml com ou sem gás',
        price: 'R$ 9',
      },
      {
        id: 'suco-perini-integral',
        name: 'Suco Perini Integral 300 ml',
        price: 'R$ 14',
      },
      {
        id: 'suco-fruta-natural',
        name: 'Suco de Fruta Natural',
        price: 'R$ 13',
      },
      {
        id: 'soda-rossa',
        name: 'Soda Rossa',
        price: 'R$ 14',
        description:
          'Bebida refrescante feita com xarope artesanal de hibisco e água gaseificada.',
      },
      {
        id: 'soda-limone',
        name: 'Soda Limone',
        price: 'R$ 14',
        description:
          'Bebida refrescante feita com xarope de capim-limão e água gaseificada.',
      },
      {
        id: 'soda-frutto-della-passione',
        name: 'Soda Frutto della Passione',
        price: 'R$ 14',
        description:
          'Bebida refrescante feita com xarope de maracujá com hibisco e água gaseificada.',
      },
      {
        id: 'refrigerante-lata',
        name: 'Refrigerante Lata 350 ml',
        price: 'R$ 9',
      },
      {
        id: 'coca-cola-ks',
        name: 'Coca-Cola KS 290 ml',
        price: 'R$ 9',
      },
      {
        id: 'mate-300ml',
        name: 'Mate 300 ml',
        price: 'R$ 9',
        description: 'Natural, limão e zero.',
      },
      {
        id: 'cafe-expresso',
        name: 'Café expresso',
        price: 'R$ 7',
      },
    ],
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Pizza Artesanal no Forno a Lenha',
    category: 'Pizzas artesanais',
    caption: 'Massa fina e borda dourada com presunto de Parma, mozzarella de búfala e rúcula fresca.',
    image: '/images/hero-trattoria.jpg',
    span: 'wide',
  },
  {
    id: 'gal-2',
    title: 'Burrata & Tomates Selecionados',
    category: 'Entradas e antepastos',
    caption: 'Cremosidade italiana finalizada com folhas frescas, azeite extra virgem e pesto de manjericão.',
    image:
      'https://images.pexels.com/photos/19252766/pexels-photo-19252766.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    span: 'standard',
  },
  {
    id: 'gal-3',
    title: 'Risoto Cremoso de Camarões',
    category: 'Massas e risotos',
    caption: 'Arroz arbóreo no ponto perfeito com camarões salteados no alho e toque cítrico.',
    image:
      'https://images.pexels.com/photos/31779537/pexels-photo-31779537.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    span: 'standard',
  },
  {
    id: 'gal-4',
    title: 'Tornedor ao Ponto com Risoto',
    category: 'Pratos italianos',
    caption: 'Corte alto de filé mignon servido com risoto cremoso de queijo parmesão e ervas.',
    image:
      'https://images.pexels.com/photos/33673982/pexels-photo-33673982.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    span: 'standard',
  },
  {
    id: 'gal-5',
    title: 'Ingredientes da Tradição Italiana',
    category: 'Detalhes da experiência gastronômica',
    caption: 'Massas frescas artesanais, Parmigiano-Reggiano, manjericão e azeite extra virgem.',
    image: '/images/heritage-table.jpg',
    span: 'standard',
  },
  {
    id: 'gal-6',
    title: 'Tiramisù & Café Expresso',
    category: 'Sobremesas',
    caption: 'Creme leve de gemas e mascarpone sobre biscoitos embebidos no café e sambuca.',
    image: '/images/tiramisu-espresso.jpg',
    span: 'wide',
  },
  {
    id: 'gal-7',
    title: 'Tagliere di Salumi e Formaggi',
    category: 'Antepastos',
    caption: 'Seleção clássica de frios, queijos italianos e pães artesanais para compartilhar à mesa.',
    image:
      'https://images.pexels.com/photos/35438980/pexels-photo-35438980.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    span: 'standard',
  },
  {
    id: 'gal-8',
    title: 'Cannoli Artesanal',
    category: 'Sobremesas',
    caption: 'Massa crocante recheada artesanalmente, expressão da confeitaria clássica italiana.',
    image:
      'https://images.pexels.com/photos/7474117/pexels-photo-7474117.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    span: 'standard',
  },
];
