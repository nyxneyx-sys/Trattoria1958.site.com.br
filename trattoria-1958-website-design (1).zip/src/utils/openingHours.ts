const RIO_TZ = 'America/Sao_Paulo';

const WEEKDAY_JS: Record<string, number> = {
  Sun: 0,
  Mon: 1,
  Tue: 2,
  Wed: 3,
  Thu: 4,
  Fri: 5,
  Sat: 6,
};

const WEEKDAY_PT = [
  'domingo',
  'segunda-feira',
  'terça-feira',
  'quarta-feira',
  'quinta-feira',
  'sexta-feira',
  'sábado',
];

const OPEN_FROM = 11 * 60 + 30;
const OPEN_UNTIL = 22 * 60 + 30;
const SOON_WINDOW = 45;

export interface RestaurantStatus {
  isOpen: boolean;
  label: string;
  detail: string;
  nextLabel: string;
  jsDay: number;
  hoursIndex: number;
  weekdayName: string;
  isClosingSoon: boolean;
  isOpeningSoon: boolean;
}

function getRioClock(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: RIO_TZ,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(now);

  const map: Record<string, string> = {};
  for (const part of parts) {
    if (part.type !== 'literal') map[part.type] = part.value;
  }

  let hour = Number(map.hour);
  if (hour === 24) hour = 0;

  const jsDay = WEEKDAY_JS[map.weekday] ?? now.getDay();
  const minute = Number(map.minute);

  return {
    jsDay,
    hour,
    minute,
    minutes: hour * 60 + minute,
  };
}

function isServiceDay(jsDay: number) {
  return jsDay >= 1 && jsDay <= 5;
}

function nextOpening(jsDay: number, minutes: number) {
  if (isServiceDay(jsDay) && minutes < OPEN_FROM) {
    return { when: 'hoje', dayName: WEEKDAY_PT[jsDay] };
  }

  if (jsDay === 5 && minutes >= OPEN_UNTIL) {
    return { when: 'segunda-feira', dayName: 'segunda-feira' };
  }

  if (jsDay === 6) {
    return { when: 'segunda-feira', dayName: 'segunda-feira' };
  }

  if (jsDay === 0) {
    return { when: 'segunda-feira', dayName: 'segunda-feira' };
  }

  const tomorrow = (jsDay + 1) % 7;
  return { when: 'amanhã', dayName: WEEKDAY_PT[tomorrow] };
}

export function getRestaurantStatus(now = new Date()): RestaurantStatus {
  const { jsDay, minutes } = getRioClock(now);
  const openToday = isServiceDay(jsDay);
  const isOpen = openToday && minutes >= OPEN_FROM && minutes < OPEN_UNTIL;
  const minutesToClose = OPEN_UNTIL - minutes;
  const minutesToOpen = OPEN_FROM - minutes;
  const isClosingSoon = isOpen && minutesToClose <= SOON_WINDOW;
  const isOpeningSoon = !isOpen && openToday && minutes < OPEN_FROM && minutesToOpen <= SOON_WINDOW;
  const next = nextOpening(jsDay, minutes);
  const hoursIndex = (jsDay + 6) % 7;

  if (isOpen) {
    return {
      isOpen: true,
      label: isClosingSoon ? 'Fecha em breve' : 'Aberto agora',
      detail: 'até 22h30',
      nextLabel: 'Fecha hoje às 22h30',
      jsDay,
      hoursIndex,
      weekdayName: WEEKDAY_PT[jsDay],
      isClosingSoon,
      isOpeningSoon: false,
    };
  }

  if (isOpeningSoon) {
    return {
      isOpen: false,
      label: 'Abre em breve',
      detail: 'hoje às 11h30',
      nextLabel: 'Abre hoje às 11h30',
      jsDay,
      hoursIndex,
      weekdayName: WEEKDAY_PT[jsDay],
      isClosingSoon: false,
      isOpeningSoon: true,
    };
  }

  const reopenText =
    next.when === 'hoje'
      ? 'abre hoje às 11h30'
      : next.when === 'amanhã'
        ? 'reabre amanhã às 11h30'
        : 'reabre segunda-feira às 11h30';

  return {
    isOpen: false,
    label: 'Fechado agora',
    detail: reopenText,
    nextLabel: reopenText.charAt(0).toUpperCase() + reopenText.slice(1),
    jsDay,
    hoursIndex,
    weekdayName: WEEKDAY_PT[jsDay],
    isClosingSoon: false,
    isOpeningSoon: false,
  };
}
