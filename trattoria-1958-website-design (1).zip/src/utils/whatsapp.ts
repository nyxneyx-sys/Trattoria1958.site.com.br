import { RESTAURANT_INFO } from '../data/menuData';
import { CartItem, CheckoutDetails, formatBRL } from '../context/CartContext';

const PAYMENT_LABELS: Record<CheckoutDetails['payment'], string> = {
  pix: 'PIX',
  dinheiro: 'Dinheiro',
  credito: 'Cartão de crédito',
  debito: 'Cartão de débito',
};

export function buildOrderWhatsAppMessage(details: CheckoutDetails, items: CartItem[], total: number): string {
  const lines: string[] = [
    `Olá, *${RESTAURANT_INFO.name}*!`,
    '',
    'Gostaria de fazer um pedido:',
    '',
    '——— *MEU PEDIDO* ———',
  ];

  items.forEach((item) => {
    const size = item.sizeLabel ? ` (${item.sizeLabel})` : '';
    const lineTotal = formatBRL(item.unitPrice * item.quantity);
    lines.push(`• ${item.quantity}x ${item.name}${size} — ${lineTotal}`);
  });

  lines.push('', `*Total do pedido:* ${formatBRL(total)}`, '', '——— *DADOS DO CLIENTE* ———');
  lines.push(`*Nome:* ${details.name.trim()}`);
  lines.push(`*Telefone:* ${details.phone.trim()}`);

  if (details.fulfillment === 'entrega') {
    const addressParts = [
      details.street.trim(),
      details.number.trim() ? `nº ${details.number.trim()}` : '',
      details.complement.trim(),
    ].filter(Boolean);

    lines.push('', '——— *ENDEREÇO DE ENTREGA* ———');
    lines.push(`*Endereço:* ${addressParts.join(', ')}`);
    if (details.neighborhood.trim()) {
      lines.push(`*Bairro:* ${details.neighborhood.trim()}`);
    }
    lines.push(`*Cidade:* ${details.city.trim() || 'Rio de Janeiro — RJ'}`);
    if (details.cep.trim()) {
      lines.push(`*CEP:* ${details.cep.trim()}`);
    }
    lines.push(`*Referência:* ${details.reference.trim()}`);
  } else {
    lines.push('', '——— *RETIRADA NO RESTAURANTE* ———');
    lines.push(RESTAURANT_INFO.addressLine1);
    lines.push(RESTAURANT_INFO.addressLine2);
    lines.push(RESTAURANT_INFO.cep);
  }

  lines.push('', `*Forma de pagamento:* ${PAYMENT_LABELS[details.payment]}`);

  if (details.notes.trim()) {
    lines.push('', `*Observações:* ${details.notes.trim()}`);
  }

  lines.push('', 'Aguardo a confirmação do pedido. Obrigado!');

  return lines.join('\n');
}

export function openWhatsAppOrder(message: string): string {
  const url = `${RESTAURANT_INFO.whatsappUrl}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
  return url;
}

export function openWhatsAppChat(prefill?: string): void {
  const url = prefill
    ? `${RESTAURANT_INFO.whatsappUrl}?text=${encodeURIComponent(prefill)}`
    : RESTAURANT_INFO.whatsappUrl;
  window.open(url, '_blank', 'noopener,noreferrer');
}
