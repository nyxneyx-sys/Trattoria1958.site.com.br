import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { MenuItem } from '../data/menuData';

export type PizzaSize = 'individual' | 'grande';

export interface CartItem {
  cartId: string;
  itemId: string;
  name: string;
  category: string;
  size?: PizzaSize;
  sizeLabel?: string;
  unitPrice: number;
  unitPriceLabel: string;
  quantity: number;
  image?: string;
}

export interface CheckoutDetails {
  name: string;
  phone: string;
  fulfillment: 'entrega' | 'retirada';
  street: string;
  number: string;
  complement: string;
  neighborhood: string;
  city: string;
  cep: string;
  reference: string;
  payment: 'pix' | 'dinheiro' | 'credito' | 'debito';
  notes: string;
}

interface CartContextValue {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addItem: (item: MenuItem, category: string, size?: PizzaSize) => void;
  increment: (cartId: string) => void;
  decrement: (cartId: string) => void;
  removeItem: (cartId: string) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

export function parseBRL(label?: string): number {
  if (!label) return 0;
  const digits = label.replace(/[^\d]/g, '');
  return Number(digits) || 0;
}

export function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function getUnitPrice(item: MenuItem, size?: PizzaSize): { value: number; label: string } {
  if (size === 'individual' && item.priceIndividual) {
    return { value: parseBRL(item.priceIndividual), label: item.priceIndividual };
  }
  if (size === 'grande' && item.priceLarge) {
    return { value: parseBRL(item.priceLarge), label: item.priceLarge };
  }
  return { value: parseBRL(item.price), label: item.price || 'R$ 0' };
}

const STORAGE_KEY = 'trattoria1958-cart';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as CartItem[]) : [];
    } catch {
      return [];
    }
  });
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  const addItem = useCallback((item: MenuItem, category: string, size?: PizzaSize) => {
    const { value, label } = getUnitPrice(item, size);
    const sizeLabel = size === 'individual' ? 'Individual' : size === 'grande' ? 'Grande' : undefined;
    const cartId = size ? `${item.id}-${size}` : item.id;

    setItems((prev) => {
      const existing = prev.find((entry) => entry.cartId === cartId);
      if (existing) {
        return prev.map((entry) =>
          entry.cartId === cartId ? { ...entry, quantity: entry.quantity + 1 } : entry
        );
      }
      return [
        ...prev,
        {
          cartId,
          itemId: item.id,
          name: item.name,
          category,
          size,
          sizeLabel,
          unitPrice: value,
          unitPriceLabel: label,
          quantity: 1,
          image: item.image,
        },
      ];
    });
    setIsOpen(true);
  }, []);

  const increment = useCallback((cartId: string) => {
    setItems((prev) =>
      prev.map((entry) => (entry.cartId === cartId ? { ...entry, quantity: entry.quantity + 1 } : entry))
    );
  }, []);

  const decrement = useCallback((cartId: string) => {
    setItems((prev) =>
      prev
        .map((entry) => (entry.cartId === cartId ? { ...entry, quantity: entry.quantity - 1 } : entry))
        .filter((entry) => entry.quantity > 0)
    );
  }, []);

  const removeItem = useCallback((cartId: string) => {
    setItems((prev) => prev.filter((entry) => entry.cartId !== cartId));
  }, []);

  const clearCart = useCallback(() => setItems([]), []);

  const itemCount = useMemo(() => items.reduce((sum, entry) => sum + entry.quantity, 0), [items]);
  const subtotal = useMemo(
    () => items.reduce((sum, entry) => sum + entry.unitPrice * entry.quantity, 0),
    [items]
  );

  const value = useMemo(
    () => ({
      items,
      itemCount,
      subtotal,
      isOpen,
      openCart: () => setIsOpen(true),
      closeCart: () => setIsOpen(false),
      addItem,
      increment,
      decrement,
      removeItem,
      clearCart,
    }),
    [items, itemCount, subtotal, isOpen, addItem, increment, decrement, removeItem, clearCart]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error('useCart must be used within CartProvider');
  }
  return ctx;
}
