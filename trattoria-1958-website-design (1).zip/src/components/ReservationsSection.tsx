import React, { useState } from 'react';
import {
  Phone,
  CalendarCheck,
  Users,
  Clock,
  Info,
  CheckCircle2,
  Copy,
  Check,
  AlertCircle,
} from 'lucide-react';
import { FloralDivider, CornerFlourish } from './BotanicalOrnaments';
import { Reveal } from './Reveal';
import { RESTAURANT_INFO } from '../data/menuData';

export const ReservationsSection: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('12h30');
  const [guests, setGuests] = useState('2 pessoas');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  // Detect if selected date falls on Saturday (6) or Sunday (0)
  const isWeekendSelected = (() => {
    if (!date) return false;
    const [year, month, day] = date.split('-').map(Number);
    if (!year || !month || !day) return false;
    const parsed = new Date(year, month - 1, day);
    const weekday = parsed.getDay();
    return weekday === 0 || weekday === 6;
  })();

  const formattedDate = (() => {
    if (!date) return '';
    const [year, month, day] = date.split('-');
    return `${day}/${month}/${year}`;
  })();

  const requestSummaryText = `Solicitação de Reserva — Trattoria 1958\nNome: ${name}\nTelefone: ${phone}\nData: ${formattedDate}\nHorário: ${time}\nPessoas: ${guests}${
    notes.trim() ? `\nObservações: ${notes.trim()}` : ''
  }`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isWeekendSelected) return;
    setSubmitted(true);
  };

  const handleCopySummary = async () => {
    try {
      await navigator.clipboard.writeText(requestSummaryText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback ignored silently
    }
  };

  return (
    <section
      id="reservas"
      className="py-20 sm:py-28 lg:py-32 bg-[#F3ECE1] border-t border-[#E5DDD0]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-start">
          {/* Left Concierge & Direct Telephone Column */}
          <Reveal className="lg:col-span-5 space-y-6" direction="left">
            <div className="space-y-3">
              <span className="inline-block text-xs font-medium uppercase tracking-[0.24em] text-[#CD212A]">
                Reservas
              </span>
              <h2 className="font-serif-editorial text-3xl sm:text-5xl font-medium text-[#1F1916] leading-[1.12]">
                Reserve sua mesa na Trattoria 1958.
              </h2>
            </div>

            <FloralDivider className="justify-start! py-1" />

            <p className="text-base text-[#5A4F48] leading-relaxed">
              Recebemos você para almoços executivos, encontros especiais e jantares no coração do Centro do Rio de Janeiro. Para atendimento imediato ou grupos maiores, entre em contato diretamente pelo telefone da casa.
            </p>

            {/* Direct Phone Call Card */}
            <div className="bg-[#CD212A] text-[#FBF8F3] border border-[#CD212A]/70 rounded-sm p-6 sm:p-8 shadow-lg space-y-4">
              <span className="inline-block text-[11px] uppercase tracking-[0.22em] text-[#FFFFFF]">
                Atendimento Telefônico Direto
              </span>
              <p className="font-serif-editorial text-3xl sm:text-4xl font-semibold tracking-wide">
                {RESTAURANT_INFO.phoneDisplay}
              </p>
              <p className="text-xs sm:text-sm text-[#EDE5D8]/85 leading-relaxed">
                Segunda a Sexta-feira, das 11h30 às 22h30 • {RESTAURANT_INFO.addressLine1}
              </p>

              <a
                href={`${RESTAURANT_INFO.whatsappUrl}?text=${encodeURIComponent(
                  `Olá, ${RESTAURANT_INFO.name}! Gostaria de reservar uma mesa.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-sm bg-[#25D366] text-white hover:bg-[#1ebe5d] font-semibold text-sm transition-colors shadow-xs"
              >
                <span>Reservar pelo WhatsApp {RESTAURANT_INFO.whatsappDisplay}</span>
              </a>
              <a
                href={RESTAURANT_INFO.phoneHref}
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-sm bg-[#FBF8F3] text-[#CD212A] hover:bg-[#F3ECE1] font-semibold text-sm transition-colors shadow-xs"
              >
                <Phone className="w-4 h-4" />
                <span>Ligar para reservar agora</span>
              </a>
            </div>

            <div className="flex items-start gap-3 text-xs text-[#5A4F48] bg-[#FFFFFF]/80 border border-[#E5DDD0] rounded-sm p-4">
              <Info className="w-4 h-4 text-[#5C5854] shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                As solicitações preenchidas ao lado são encaminhadas para verificação de disponibilidade junto à equipe da casa e não constituem confirmação automática sem retorno telefônico.
              </p>
            </div>
          </Reveal>

          <Reveal className="lg:col-span-7" direction="right" delay={120}>
            <div className="relative bg-[#FFFFFF] border border-[#E5DDD0] rounded-sm p-6 sm:p-10 shadow-[0_16px_44px_rgba(31,25,22,0.06)]">
              <CornerFlourish className="absolute top-2.5 left-2.5" />
              <CornerFlourish className="absolute top-2.5 right-2.5 rotate-90" />
              <CornerFlourish className="absolute bottom-2.5 left-2.5 -rotate-90" />
              <CornerFlourish className="absolute bottom-2.5 right-2.5 rotate-180" />

              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="border-b border-[#E5DDD0] pb-4">
                    <h3 className="font-serif-editorial text-2xl sm:text-3xl font-semibold text-[#1F1916]">
                      Solicitar uma Mesa
                    </h3>
                    <p className="text-xs sm:text-sm text-[#5A4F48] mt-1">
                      Preencha os dados abaixo para registrar sua solicitação de reserva.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label
                        htmlFor="res-name"
                        className="block text-xs font-semibold uppercase tracking-wider text-[#1F1916] mb-2"
                      >
                        Nome completo *
                      </label>
                      <input
                        id="res-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Seu nome"
                        className="w-full px-4 py-3 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] focus:outline-none focus:border-[#CD212A]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="res-phone"
                        className="block text-xs font-semibold uppercase tracking-wider text-[#1F1916] mb-2"
                      >
                        Telefone / WhatsApp *
                      </label>
                      <input
                        id="res-phone"
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="(21) 99999-9999"
                        className="w-full px-4 py-3 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] focus:outline-none focus:border-[#CD212A]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    <div>
                      <label
                        htmlFor="res-date"
                        className="block text-xs font-semibold uppercase tracking-wider text-[#1F1916] mb-2"
                      >
                        Data desejada *
                      </label>
                      <input
                        id="res-date"
                        type="date"
                        required
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full px-4 py-3 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] focus:outline-none focus:border-[#CD212A]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="res-time"
                        className="block text-xs font-semibold uppercase tracking-wider text-[#1F1916] mb-2"
                      >
                        <span className="inline-flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-[#5C5854]" />
                          Horário
                        </span>
                      </label>
                      <select
                        id="res-time"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        className="w-full px-4 py-3 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] focus:outline-none focus:border-[#CD212A]"
                      >
                        <option value="11h30">11h30</option>
                        <option value="12h00">12h00</option>
                        <option value="12h30">12h30</option>
                        <option value="13h00">13h00</option>
                        <option value="13h30">13h30</option>
                        <option value="14h00">14h00</option>
                        <option value="18h30">18h30</option>
                        <option value="19h00">19h00</option>
                        <option value="19h30">19h30</option>
                        <option value="20h00">20h00</option>
                        <option value="20h30">20h30</option>
                        <option value="21h00">21h00</option>
                        <option value="21h30">21h30</option>
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="res-guests"
                        className="block text-xs font-semibold uppercase tracking-wider text-[#1F1916] mb-2"
                      >
                        <span className="inline-flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-[#5C5854]" />
                          Pessoas
                        </span>
                      </label>
                      <select
                        id="res-guests"
                        value={guests}
                        onChange={(e) => setGuests(e.target.value)}
                        className="w-full px-4 py-3 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] focus:outline-none focus:border-[#CD212A]"
                      >
                        <option value="1 pessoa">1 pessoa</option>
                        <option value="2 pessoas">2 pessoas</option>
                        <option value="3 pessoas">3 pessoas</option>
                        <option value="4 pessoas">4 pessoas</option>
                        <option value="5 pessoas">5 pessoas</option>
                        <option value="6 pessoas">6 pessoas</option>
                        <option value="7 ou mais pessoas">7 ou mais pessoas</option>
                      </select>
                    </div>
                  </div>

                  {isWeekendSelected && (
                    <div
                      role="alert"
                      className="flex items-start gap-3 p-4 rounded-sm bg-[#CD212A]/8 border border-[#CD212A]/30 text-sm text-[#CD212A]"
                    >
                      <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold">
                          A Trattoria 1958 permanece fechada aos sábados e domingos.
                        </p>
                        <p className="text-xs mt-0.5 text-[#5A4F48]">
                          Por favor, selecione uma data entre segunda-feira e sexta-feira (horário de funcionamento: 11h30 às 22h30).
                        </p>
                      </div>
                    </div>
                  )}

                  <div>
                    <label
                      htmlFor="res-notes"
                      className="block text-xs font-semibold uppercase tracking-wider text-[#1F1916] mb-2"
                    >
                      Observações (opcional)
                    </label>
                    <textarea
                      id="res-notes"
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Ex.: solicitação de cadeira alta para criança, acessibilidade ou ocasião especial"
                      className="w-full px-4 py-3 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] focus:outline-none focus:border-[#CD212A]"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isWeekendSelected}
                    className="w-full inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-sm bg-[#CD212A] hover:bg-[#A81A22] disabled:opacity-50 disabled:cursor-not-allowed text-[#FBF8F3] font-medium text-sm sm:text-base tracking-[0.03em] border border-[#CD212A]/70 transition-colors"
                  >
                    <CalendarCheck className="w-4 h-4 text-[#FFFFFF]" />
                    <span>Enviar solicitação de reserva</span>
                  </button>
                </form>
              ) : (
                /* Honest Pending Confirmation Summary State */
                <div className="space-y-6 py-2 animate-editorial-in">
                  <div className="flex items-start gap-4">
                    <div className="w-11 h-11 rounded-full bg-[#3E4D3B]/15 text-[#3E4D3B] flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[11px] uppercase tracking-[0.22em] font-semibold text-[#5C5854]">
                        Solicitação Registrada — Sujeita à Confirmação
                      </span>
                      <h3 className="font-serif-editorial text-2xl sm:text-3xl font-semibold text-[#1F1916] mt-0.5">
                        Solicitação preparada para a equipe da Trattoria 1958
                      </h3>
                      <p className="text-sm text-[#5A4F48] mt-2 leading-relaxed">
                        Como este site não possui integração automática com o sistema interno do salão, sua reserva ainda aguarda confirmação. Ligue diretamente para nossa recepção para confirmar sua mesa imediatamente:
                      </p>
                    </div>
                  </div>

                  <div className="bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm p-5 space-y-2 text-sm">
                    <p>
                      <strong className="text-[#1F1916]">Nome:</strong>{' '}
                      <span className="text-[#5A4F48]">{name}</span>
                    </p>
                    <p>
                      <strong className="text-[#1F1916]">Telefone:</strong>{' '}
                      <span className="text-[#5A4F48]">{phone}</span>
                    </p>
                    <p>
                      <strong className="text-[#1F1916]">Data e horário:</strong>{' '}
                      <span className="text-[#5A4F48]">
                        {formattedDate} às {time}
                      </span>
                    </p>
                    <p>
                      <strong className="text-[#1F1916]">Quantidade:</strong>{' '}
                      <span className="text-[#5A4F48]">{guests}</span>
                    </p>
                    {notes.trim() && (
                      <p>
                        <strong className="text-[#1F1916]">Observações:</strong>{' '}
                        <span className="text-[#5A4F48]">{notes.trim()}</span>
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href={`${RESTAURANT_INFO.whatsappUrl}?text=${encodeURIComponent(requestSummaryText)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-sm bg-[#25D366] text-white text-sm font-medium hover:bg-[#1ebe5d] transition-colors"
                    >
                      <span>Enviar reserva no WhatsApp</span>
                    </a>
                    <a
                      href={RESTAURANT_INFO.phoneHref}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-sm bg-[#CD212A] text-[#FBF8F3] text-sm font-medium hover:bg-[#A81A22] transition-colors"
                    >
                      <Phone className="w-4 h-4 text-[#FFFFFF]" />
                      <span>Ligar: {RESTAURANT_INFO.phoneDisplay}</span>
                    </a>

                    <button
                      type="button"
                      onClick={handleCopySummary}
                      className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-sm border border-[#CD212A] text-[#1F1916] text-sm font-medium hover:bg-[#F3ECE1] transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 text-[#3E4D3B]" />
                          <span>Resumo copiado</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 text-[#CD212A]" />
                          <span>Copiar resumo</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="text-xs font-medium text-[#CD212A] underline underline-offset-4 hover:text-[#A81A22]"
                    >
                      Editar dados da solicitação
                    </button>
                  </div>
                </div>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};
