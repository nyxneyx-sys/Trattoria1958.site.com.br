import React, { useState } from 'react';
import { Check, Plus, ShoppingBag } from 'lucide-react';
import type { MenuItem } from '../data/menuData';
import { PizzaSize, useCart } from '../context/CartContext';

interface Props {
  item: MenuItem;
  category: string;
  compact?: boolean;
}

export const AddToCartControls: React.FC<Props> = ({ item, category, compact = false }) => {
  const { addItem } = useCart();
  const [added, setAdded] = useState<string | null>(null);
  const isPizza = Boolean(item.priceIndividual && item.priceLarge);

  const handleAdd = (e: React.MouseEvent, size?: PizzaSize) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(item, category, size);
    const key = size || 'default';
    setAdded(key);
    window.setTimeout(() => setAdded(null), 1400);
  };

  if (isPizza) {
    return (
      <div
        className={`flex flex-wrap gap-2 ${compact ? 'mt-3' : 'mt-4'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <AddBtn
          label="Adicionar Individual"
          active={added === 'individual'}
          onClick={(e) => handleAdd(e, 'individual')}
        />
        <AddBtn
          label="Adicionar Grande"
          active={added === 'grande'}
          onClick={(e) => handleAdd(e, 'grande')}
          emphasis
        />
      </div>
    );
  }

  return (
    <div className={compact ? 'mt-3' : 'mt-4'} onClick={(e) => e.stopPropagation()}>
      <AddBtn
        label="Adicionar ao pedido"
        active={added === 'default'}
        onClick={(e) => handleAdd(e)}
        emphasis
        full={!compact}
      />
    </div>
  );
};

const AddBtn: React.FC<{
  label: string;
  active: boolean;
  onClick: (e: React.MouseEvent) => void;
  emphasis?: boolean;
  full?: boolean;
}> = ({ label, active, onClick, emphasis = false, full = false }) => (
  <button
    type="button"
    onClick={onClick}
    className={`inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-sm text-xs font-medium tracking-[0.02em] transition-colors ${
      full ? 'w-full' : ''
    } ${
      active
        ? 'bg-[#008C45] text-white'
        : emphasis
          ? 'bg-[#CD212A] text-white hover:bg-[#A81A22]'
          : 'bg-white text-[#111111] border border-[#E6E1D8] hover:border-[#CD212A] hover:text-[#CD212A]'
    }`}
  >
    {active ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
    <span>{active ? 'Adicionado' : label}</span>
  </button>
);

export const ModalAddToCart: React.FC<{ item: MenuItem; category: string; onAdded: () => void }> = ({
  item,
  category,
  onAdded,
}) => {
  const { addItem } = useCart();
  const isPizza = Boolean(item.priceIndividual && item.priceLarge);
  const [size, setSize] = useState<PizzaSize>('grande');

  const handleAdd = () => {
    addItem(item, category, isPizza ? size : undefined);
    onAdded();
  };

  return (
    <div className="space-y-3">
      {isPizza && (
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setSize('individual')}
            className={`px-3 py-2.5 rounded-sm border text-sm ${
              size === 'individual'
                ? 'border-[#CD212A] bg-[#CD212A] text-white'
                : 'border-[#E6E1D8] bg-white'
            }`}
          >
            Individual — {item.priceIndividual}
          </button>
          <button
            type="button"
            onClick={() => setSize('grande')}
            className={`px-3 py-2.5 rounded-sm border text-sm ${
              size === 'grande'
                ? 'border-[#CD212A] bg-[#CD212A] text-white'
                : 'border-[#E6E1D8] bg-white'
            }`}
          >
            Grande — {item.priceLarge}
          </button>
        </div>
      )}
      <button
        type="button"
        onClick={handleAdd}
        className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-sm bg-[#CD212A] text-white text-sm font-medium hover:bg-[#A81A22]"
      >
        <ShoppingBag className="w-4 h-4" />
        Adicionar ao pedido
      </button>
    </div>
  );
};
