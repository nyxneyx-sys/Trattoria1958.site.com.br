import React from 'react';
import { Star, UtensilsCrossed, CalendarCheck, ArrowDown } from 'lucide-react';
import { Logo } from './Logo';
import { OpenStatusBadge } from './OpenStatusBadge';
import { RESTAURANT_INFO } from '../data/menuData';

export const HeroSection: React.FC = () => {
  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] w-full flex items-center overflow-hidden bg-[#170F0D]"
    >
      {/* Cinematic Background Image */}
      <img
        src="/images/hero-trattoria.jpg"
        alt="Pizza artesanal italiana servida sobre mesa posta na Trattoria 1958"
        className="absolute inset-0 w-full h-full object-cover object-center hero-kenburns"
      />

      {/* Warm Cinematographic Vignette & Editorial Gradient Overlay */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-[#140B09]/92 via-[#1A0E0C]/75 to-[#140B09]/45"
        aria-hidden="true"
      />
      <div
        className="absolute inset-0 bg-gradient-to-t from-[#140B09]/85 via-transparent to-[#140B09]/55"
        aria-hidden="true"
      />

      {/* Subtle Top & Bottom Hairline Gold Framing */}
      <div
        className="hidden md:block absolute inset-x-8 top-24 bottom-8 border border-[#FFFFFF]/20 pointer-events-none"
        aria-hidden="true"
      />

      {/* Hero Editorial Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 pt-32 pb-20 sm:pt-36 sm:pb-24 w-full">
        <div className="max-w-3xl hero-stagger">
          <div className="mb-8 hidden sm:block">
            <Logo variant="light" size="lg" />
          </div>

          <div className="inline-flex items-center gap-3 mb-5">
            <span className="h-px w-8 bg-white" />
            <span className="text-xs sm:text-[13px] font-medium uppercase tracking-[0.24em] text-[#F5F5F5]">
              Centro do Rio de Janeiro • Tradição desde a década de 1950
            </span>
          </div>

          {/* Main Title */}
          <h1 className="font-serif-editorial text-4xl sm:text-5xl md:text-6xl lg:text-[66px] font-medium text-[#FBF8F3] leading-[1.08] tracking-[-0.01em] mb-6">
            Uma tradição italiana que atravessa gerações.
          </h1>

          {/* Subtitle */}
          <p className="font-sans-clean text-base sm:text-lg md:text-[19px] text-[#EDE5D8]/90 font-light leading-relaxed max-w-2xl mb-8">
            Sabores autênticos, ingredientes selecionados e uma experiência gastronômica especial no coração do Rio de Janeiro.
          </p>

          {/* Primary & Secondary CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-12">
            <a
              href="#cardapio"
              className="btn-lift inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-sm bg-[#CD212A] hover:bg-[#A81A22] text-[#FBF8F3] font-medium text-sm sm:text-base tracking-[0.03em] border border-[#CD212A]/75 shadow-lg"
            >
              <UtensilsCrossed className="w-4 h-4 text-[#FFFFFF]" />
              <span>Conheça nosso cardápio</span>
            </a>

            <a
              href="#reservas"
              className="btn-lift inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-sm bg-[#FBF8F3]/10 hover:bg-[#FBF8F3]/18 backdrop-blur-xs text-[#FBF8F3] font-medium text-sm sm:text-base tracking-[0.03em] border border-[#FBF8F3]/35 hover:border-[#FFFFFF]"
            >
              <CalendarCheck className="w-4 h-4 text-[#FFFFFF]" />
              <span>Reserve sua mesa</span>
            </a>
          </div>

          {/* Institutional Credentials & Rating Bar */}
          <div className="pt-6 border-t border-[#FFFFFF]/25 flex flex-col lg:flex-row lg:flex-wrap items-start lg:items-center gap-4 lg:gap-7 text-sm text-[#F3ECE1]">
            <OpenStatusBadge variant="hero" />

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-0.5 text-[#FFFFFF]" aria-hidden="true">
                <Star className="w-4 h-4 fill-[#FFFFFF] text-[#FFFFFF]" />
              </div>
              <span className="font-semibold text-[#FBF8F3]">{RESTAURANT_INFO.rating} estrelas</span>
              <span className="text-[#FFFFFF]/60">•</span>
              <span className="text-[#EDE5D8]/85">{RESTAURANT_INFO.reviewCount} avaliações</span>
            </div>

            <span className="hidden lg:inline text-[#FFFFFF]/40">|</span>

            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#CD212A]" />
              <span className="text-[#EDE5D8]/90">{RESTAURANT_INFO.categoryLabel}</span>
            </div>

            <span className="hidden lg:inline text-[#FFFFFF]/40">|</span>

            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#CD212A]" />
              <span className="text-[#EDE5D8]/90">
                Faixa de preço: <strong className="font-medium text-[#FBF8F3]">{RESTAURANT_INFO.priceRange}</strong>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Subtle Scroll Hint */}
      <a
        href="#historia"
        aria-label="Explorar nossa história"
        className="hidden md:flex flex-col items-center gap-1.5 absolute bottom-6 right-12 z-10 text-[#F5F5F5]/80 hover:text-[#FBF8F3] transition-colors text-[11px] uppercase tracking-[0.22em]"
      >
        <span>Explorar</span>
        <ArrowDown className="w-3.5 h-3.5 animate-float-hint" />
      </a>
    </section>
  );
};
