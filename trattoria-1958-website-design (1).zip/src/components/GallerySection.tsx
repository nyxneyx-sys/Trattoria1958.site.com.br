import React, { useState } from 'react';
import { Expand, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/menuData';
import { FloralDivider } from './BotanicalOrnaments';
import { Reveal } from './Reveal';

export const GallerySection: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedIndex === null) return;
    setSelectedIndex((selectedIndex - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedIndex === null) return;
    setSelectedIndex((selectedIndex + 1) % GALLERY_ITEMS.length);
  };

  return (
    <section id="galeria" className="py-20 sm:py-28 lg:py-32 bg-[#FBF8F3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Section Header */}
        <Reveal className="max-w-3xl mx-auto text-center space-y-4 mb-14">
          <span className="inline-block text-xs font-medium uppercase tracking-[0.24em] text-[#CD212A]">
            Experiência Gastronômica
          </span>
          <h2 className="font-serif-editorial text-3xl sm:text-5xl lg:text-[52px] font-medium text-[#1F1916] leading-[1.1]">
            Galeria de Sabores
          </h2>
          <p className="text-sm sm:text-base text-[#5A4F48] max-w-2xl mx-auto leading-relaxed">
            Pizzas artesanais, risotos cremosos, antepastos clássicos, sobremesas tradicionais e os detalhes que celebram a culinária italiana.
          </p>
          <FloralDivider className="pt-2" />
        </Reveal>

        {/* Editorial Bento Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
          {GALLERY_ITEMS.map((item, idx) => {
            const isWide = item.span === 'wide';

            return (
              <Reveal
                key={item.id}
                delay={idx * 70}
                className={isWide ? 'sm:col-span-2' : ''}
              >
              <figure
                onClick={() => setSelectedIndex(idx)}
                className={`group relative overflow-hidden rounded-sm bg-[#1F1916] border border-[#E5DDD0] cursor-pointer card-lift ${
                  isWide ? 'aspect-[16/10]' : 'aspect-[4/3]'
                }`}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105 opacity-95 group-hover:opacity-100"
                  loading="lazy"
                />

                {/* Subtle Gradient Caption Overlay */}
                <div
                  className="absolute inset-0 bg-gradient-to-t from-[#140B09]/85 via-[#140B09]/20 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"
                  aria-hidden="true"
                />

                {/* Expand Badge */}
                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[#1F1916]/60 backdrop-blur-xs border border-[#FBF8F3]/25 text-[#FBF8F3] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Expand className="w-4 h-4" />
                </div>

                {/* Caption */}
                <figcaption className="absolute inset-x-0 bottom-0 p-5 sm:p-6 text-[#FBF8F3]">
                  <span className="block text-[11px] uppercase tracking-[0.2em] text-[#FFFFFF] mb-1">
                    {item.category}
                  </span>
                  <h3 className="font-serif-editorial text-xl sm:text-2xl font-medium leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#EDE5D8]/85 mt-1 line-clamp-2 opacity-90">
                    {item.caption}
                  </p>
                </figcaption>
              </figure>
              </Reveal>
            );
          })}
        </div>
      </div>

      {/* Fullscreen Lightbox */}
      {selectedIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-[#120A08]/92 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 animate-fade-overlay"
          onClick={() => setSelectedIndex(null)}
          role="dialog"
          aria-modal="true"
          aria-label={GALLERY_ITEMS[selectedIndex].title}
        >
          <button
            type="button"
            onClick={() => setSelectedIndex(null)}
            aria-label="Fechar galeria"
            className="absolute top-5 right-5 w-11 h-11 rounded-full bg-[#FBF8F3]/10 hover:bg-[#CD212A] text-[#FBF8F3] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={handlePrev}
            aria-label="Imagem anterior"
            className="absolute left-3 sm:left-6 w-11 h-11 rounded-full bg-[#FBF8F3]/10 hover:bg-[#CD212A] text-[#FBF8F3] flex items-center justify-center transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div
            className="max-w-4xl w-full bg-[#1C1210] border border-[#CD212A]/40 rounded-sm overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="aspect-[16/10] bg-black">
              <img
                src={GALLERY_ITEMS[selectedIndex].image}
                alt={GALLERY_ITEMS[selectedIndex].title}
                className="w-full h-full object-cover object-center"
              />
            </div>
            <div className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-[#FBF8F3]">
              <div>
                <span className="text-[11px] uppercase tracking-[0.22em] text-[#FFFFFF]">
                  {GALLERY_ITEMS[selectedIndex].category}
                </span>
                <h3 className="font-serif-editorial text-2xl sm:text-3xl font-medium mt-0.5">
                  {GALLERY_ITEMS[selectedIndex].title}
                </h3>
                <p className="text-sm text-[#EDE5D8]/85 mt-1">
                  {GALLERY_ITEMS[selectedIndex].caption}
                </p>
              </div>
              <span className="text-xs text-[#FFFFFF] shrink-0">
                {selectedIndex + 1} / {GALLERY_ITEMS.length}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleNext}
            aria-label="Próxima imagem"
            className="absolute right-3 sm:right-6 w-11 h-11 rounded-full bg-[#FBF8F3]/10 hover:bg-[#CD212A] text-[#FBF8F3] flex items-center justify-center transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </section>
  );
};
