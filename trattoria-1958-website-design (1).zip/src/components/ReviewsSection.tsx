import React from 'react';
import { Star, Utensils, Music, HeartHandshake, Award } from 'lucide-react';
import { FloralDivider, CornerFlourish } from './BotanicalOrnaments';
import { RESTAURANT_INFO } from '../data/menuData';
import { Reveal } from './Reveal';

const HIGHLIGHTS = [
  {
    icon: Utensils,
    title: 'Pizzas de Massa Fina & Massas Frescas',
    description:
      'Gastronomia italiana elogiada pelo sabor autêntico e pelo cuidado no preparo artesanal.',
  },
  {
    icon: Award,
    title: 'Menu Executivo',
    description:
      'Reconhecido pelo excelente custo-benefício no coração comercial do Rio de Janeiro.',
  },
  {
    icon: Music,
    title: 'Ambiente Acolhedor & Música Clássica',
    description:
      'Atmosfera agradável e tradicional, frequentemente acompanhada de música clássica.',
  },
  {
    icon: HeartHandshake,
    title: 'Atendimento Atencioso',
    description:
      'Equipe educada, eficiente e dedicada a tornar cada visita memorável.',
  },
];

export const ReviewsSection: React.FC = () => {
  return (
    <section
      id="avaliacoes"
      className="relative py-20 sm:py-28 lg:py-32 bg-[#111111] text-[#FBF8F3] overflow-hidden"
    >
      {/* Subtle Radial Warmth */}
      <div
        className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(205,33,42,0.18),transparent_55%)] pointer-events-none"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Top Rating Plaque + Editorial Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* Left Rating Crest Card */}
          <Reveal className="lg:col-span-5" direction="left">
            <div className="relative bg-[#1A1A1A]/90 border border-[#FFFFFF]/45 rounded-sm p-8 sm:p-11 text-center shadow-2xl">
              <CornerFlourish light className="absolute top-2.5 left-2.5" />
              <CornerFlourish light className="absolute top-2.5 right-2.5 rotate-90" />
              <CornerFlourish light className="absolute bottom-2.5 left-2.5 -rotate-90" />
              <CornerFlourish light className="absolute bottom-2.5 right-2.5 rotate-180" />

              <span className="inline-block text-[11px] uppercase tracking-[0.24em] text-[#FFFFFF] mb-3">
                Reconhecimento dos Visitantes
              </span>

              <div className="font-serif-editorial text-6xl sm:text-7xl font-semibold text-[#FBF8F3] leading-none my-2 tabular-price">
                4,6
              </div>

              <p className="font-serif-editorial italic text-xl sm:text-2xl text-[#F5F5F5] mb-4">
                de 5 estrelas
              </p>

              {/* 5 Golden Stars */}
              <div
                className="flex items-center justify-center gap-1.5 mb-5"
                aria-label="Avaliação de 4,6 de 5 estrelas"
              >
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className="w-5 h-5 fill-[#FFFFFF] text-[#FFFFFF]"
                  />
                ))}
              </div>

              <div className="inline-block px-5 py-2 rounded-full bg-[#CD212A] border border-[#FFFFFF]/40 text-sm font-medium text-[#FBF8F3] tracking-wide">
                {RESTAURANT_INFO.reviewCount} avaliações
              </div>

              <p className="text-xs text-[#EDE5D8]/75 mt-5">
                {RESTAURANT_INFO.categoryLabel} • {RESTAURANT_INFO.priceRange}
              </p>
            </div>
          </Reveal>

          <Reveal className="lg:col-span-7 space-y-6" direction="right" delay={120}>
            <div className="space-y-3">
              <span className="inline-block text-xs font-medium uppercase tracking-[0.24em] text-[#FFFFFF]">
                Avaliações dos Clientes
              </span>
              <h2 className="font-serif-editorial text-3xl sm:text-5xl font-medium text-[#FBF8F3] leading-[1.12]">
                O sabor de uma experiência especial.
              </h2>
            </div>

            <FloralDivider light className="justify-start! py-1" />

            <div className="space-y-5 text-base sm:text-[17px] text-[#EDE5D8]/90 leading-[1.85] font-light">
              <p>
                Os clientes elogiam a deliciosa comida italiana do restaurante, incluindo pizzas de massa fina e massas frescas, além do excelente custo-benefício do menu executivo.
              </p>
              <p>
                O ambiente agradável e acolhedor, frequentemente acompanhado de música clássica, também é um dos pontos destacados pelos visitantes.
              </p>
              <p>
                O atendimento atencioso, educado e eficiente completa a experiência.
              </p>
            </div>
          </Reveal>
        </div>

        {/* Four Authentic Pillars Derived Strictly from Guest Consensus */}
        <div className="mt-16 pt-12 border-t border-[#FFFFFF]/25 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {HIGHLIGHTS.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="card-lift bg-[#1A1A1A]/65 border border-[#FFFFFF]/25 rounded-sm p-6 space-y-3"
              >
                <div className="w-10 h-10 rounded-full bg-[#CD212A] border border-[#FFFFFF]/45 flex items-center justify-center text-[#FFFFFF]">
                  <Icon className="w-4 h-4" />
                </div>
                <h3 className="font-serif-editorial text-xl font-medium text-[#FBF8F3] leading-snug">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#EDE5D8]/80 leading-relaxed">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
