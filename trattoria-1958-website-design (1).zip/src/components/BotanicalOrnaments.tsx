import React from 'react';

interface DividerProps {
  className?: string;
  light?: boolean;
}

export const FloralDivider: React.FC<DividerProps> = ({ className = '', light = false }) => {
  const strokeColor = light ? 'rgba(255,255,255,0.7)' : '#111111';

  return (
    <div className={`flex items-center justify-center gap-3 select-none ${className}`} aria-hidden="true">
      <span
        className={`h-px w-12 sm:w-20 ${
          light ? 'bg-gradient-to-r from-transparent to-white/50' : 'bg-gradient-to-r from-transparent to-[#111111]/50'
        }`}
      />
      <svg
        width="54"
        height="20"
        viewBox="0 0 54 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        {/* Italian flag oval at center — brand motif */}
        <rect x="22.2" y="4.2" width="9.6" height="11.6" rx="1.6" fill="#008C45" />
        <rect x="25.4" y="4.2" width="3.2" height="11.6" fill="#F5F5F5" />
        <rect x="28.6" y="4.2" width="3.2" height="11.6" rx="0" fill="#CD212A" />
        <rect x="22.2" y="4.2" width="9.6" height="11.6" rx="1.6" fill="transparent" stroke={strokeColor} strokeOpacity="0.15" />

        {/* Left olive sprig */}
        <path
          d="M20 10C16 10 12 9.5 6 10"
          stroke={strokeColor}
          strokeWidth="1"
          strokeLinecap="round"
        />
        <path
          d="M16.5 9.8C15 7.5 12.8 6.6 10.8 7.4C12.2 9.2 14.4 10 16.5 9.8Z"
          stroke={strokeColor}
          strokeWidth="1"
        />
        <path
          d="M13.8 10.2C12.4 12.5 10.2 13.4 8.2 12.6C9.6 10.8 11.8 10 13.8 10.2Z"
          stroke={strokeColor}
          strokeWidth="1"
        />
        {/* Right olive sprig */}
        <path
          d="M34 10C38 10 42 9.5 48 10"
          stroke={strokeColor}
          strokeWidth="1"
          strokeLinecap="round"
        />
        <path
          d="M37.5 9.8C39 7.5 41.2 6.6 43.2 7.4C41.8 9.2 39.6 10 37.5 9.8Z"
          stroke={strokeColor}
          strokeWidth="1"
        />
        <path
          d="M40.2 10.2C41.6 12.5 43.8 13.4 45.8 12.6C44.4 10.8 42.2 10 40.2 10.2Z"
          stroke={strokeColor}
          strokeWidth="1"
        />
      </svg>
      <span
        className={`h-px w-12 sm:w-20 ${
          light ? 'bg-gradient-to-l from-transparent to-white/50' : 'bg-gradient-to-l from-transparent to-[#111111]/50'
        }`}
      />
    </div>
  );
};

export const CornerFlourish: React.FC<{ className?: string; light?: boolean }> = ({
  className = '',
  light = false,
}) => {
  const stroke = light ? '#FFFFFF' : '#111111';
  return (
    <svg
      width="36"
      height="36"
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`pointer-events-none select-none ${className}`}
      aria-hidden="true"
    >
      <path
        d="M2 34V14C2 7.37258 7.37258 2 14 2H34"
        stroke={stroke}
        strokeOpacity="0.35"
        strokeWidth="1"
      />
      <path
        d="M6 30V15C6 10.0294 10.0294 6 15 6H30"
        stroke={stroke}
        strokeOpacity="0.18"
        strokeWidth="0.8"
      />
      <rect x="7" y="7" width="5.4" height="5.4" rx="0.6" fill="#008C45" />
      <rect x="8.8" y="7" width="1.8" height="5.4" fill="#F5F5F5" />
      <rect x="10.6" y="7" width="1.8" height="5.4" fill="#CD212A" />
    </svg>
  );
};
