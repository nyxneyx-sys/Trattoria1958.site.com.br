import React from 'react';
import {
  MapPin,
  Phone,
  ExternalLink,
  Clock,
  Wifi,
  Accessibility,
  Baby,
  CalendarCheck,
  MessageCircle,
} from 'lucide-react';
import { FloralDivider } from './BotanicalOrnaments';
import { Reveal } from './Reveal';
import { OpenStatusBadge } from './OpenStatusBadge';
import { useRestaurantStatus } from '../hooks/useRestaurantStatus';
import { RESTAURANT_INFO, OPENING_HOURS } from '../data/menuData';

const AMENITIES = [
  {
    icon: Accessibility,
    label: 'Acessibilidade',
    detail: 'Acesso preparado para receber todos os clientes com conforto.',
  },
  {
    icon: Wifi,
    label: 'Wi-Fi',
    detail: 'Conexão Wi-Fi disponível para nossos clientes no salão.',
  },
  {
    icon: Baby,
    label: 'Cadeiras altas para crianças',
    detail: 'Estrutura acolhedora para famílias com crianças.',
  },
  {
    icon: CalendarCheck,
    label: 'Reservas de mesas',
    detail: 'Possibilidade de reservar mesas com antecedência.',
  },
];

export const LocationSection: React.FC = () => {
  const status = useRestaurantStatus();

  return (
    <section id="localizacao" className="py-20 sm:py-28 lg:py-32 bg-[#FBF8F3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Section Header */}
        <Reveal className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="inline-block text-xs font-medium uppercase tracking-[0.24em] text-[#CD212A]">
            Localização & Horários
          </span>
          <h2 className="font-serif-editorial text-3xl sm:text-5xl lg:text-[54px] font-medium text-[#1F1916] leading-[1.1]">
            Estamos esperando por você.
          </h2>
          <p className="text-sm sm:text-base text-[#5A4F48] max-w-xl mx-auto leading-relaxed">
            No coração comercial do Rio de Janeiro, com fácil acesso e toda a hospitalidade da tradição italiana.
          </p>
          <FloralDivider className="pt-2" />
        </Reveal>

        {/* Main 12-Col Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          {/* Left Column: Address, Contact, Amenities & Hours */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            {/* Address & Phone Card */}
            <div className="bg-[#FFFFFF] border border-[#E5DDD0] rounded-sm p-6 sm:p-8 shadow-xs space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-full bg-[#FBF8F3] border border-[#CD212A]/60 flex items-center justify-center shrink-0 text-[#CD212A]">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-[0.2em] text-[#5C5854] font-semibold">
                    Endereço
                  </span>
                  <address className="not-italic mt-1.5 text-base text-[#1F1916] leading-relaxed">
                    <strong className="font-semibold block">{RESTAURANT_INFO.addressLine1}</strong>
                    <span className="block text-[#5A4F48]">{RESTAURANT_INFO.addressLine2}</span>
                    <span className="block text-[#5A4F48]">{RESTAURANT_INFO.cep}</span>
                  </address>
                </div>
              </div>

              <div className="flex items-start gap-4 pt-5 border-t border-[#E5DDD0]/80">
                <div className="w-11 h-11 rounded-full bg-[#FBF8F3] border border-[#CD212A]/60 flex items-center justify-center shrink-0 text-[#CD212A]">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-[0.2em] text-[#5C5854] font-semibold">
                    Telefone
                  </span>
                  <a
                    href={RESTAURANT_INFO.phoneHref}
                    className="block mt-1 font-serif-editorial text-2xl font-semibold text-[#1F1916] hover:text-[#CD212A] transition-colors"
                  >
                    {RESTAURANT_INFO.phoneDisplay}
                  </a>
                </div>
              </div>

              {/* Direct Action Buttons */}
              <div className="pt-2 flex flex-col gap-3">
                <a
                  href={`${RESTAURANT_INFO.whatsappUrl}?text=${encodeURIComponent(
                    `Olá, ${RESTAURANT_INFO.name}! Gostaria de informações sobre pedidos e reservas.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-sm bg-[#25D366] text-white text-sm font-medium hover:bg-[#1ebe5d] transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp {RESTAURANT_INFO.whatsappDisplay}</span>
                </a>
                <div className="flex flex-col sm:flex-row gap-3">
                  <a
                    href={RESTAURANT_INFO.phoneHref}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-sm bg-[#CD212A] text-[#FBF8F3] text-sm font-medium hover:bg-[#A81A22] transition-colors"
                  >
                    <Phone className="w-4 h-4 text-[#FFFFFF]" />
                    <span>Ligar diretamente</span>
                  </a>

                  <a
                    href={RESTAURANT_INFO.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-sm border border-[#CD212A] text-[#1F1916] text-sm font-medium hover:bg-[#F3ECE1] transition-colors"
                  >
                    <ExternalLink className="w-4 h-4 text-[#CD212A]" />
                    <span>Abrir no Google Maps</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Horários de Funcionamento Card */}
            <div className="bg-[#FFFFFF] border border-[#E5DDD0] rounded-sm p-6 sm:p-8 shadow-xs">
              <div className="flex items-center gap-3 mb-5 pb-4 border-b border-[#E5DDD0]">
                <Clock className="w-5 h-5 text-[#CD212A]" />
                <h3 className="font-serif-editorial text-2xl font-semibold text-[#1F1916]">
                  Horários de Funcionamento
                </h3>
              </div>

              <div className="mb-5">
                <OpenStatusBadge variant="panel" />
              </div>

              <dl className="divide-y divide-[#E5DDD0]/70 text-sm">
                {OPENING_HOURS.map((slot, index) => {
                  const isToday = index === status.hoursIndex;
                  return (
                    <div
                      key={slot.day}
                      className={`py-2.5 flex items-center justify-between gap-4 px-2 -mx-2 rounded-sm ${
                        isToday ? 'bg-[#F3EEE7]' : ''
                      }`}
                    >
                      <dt className={`font-medium ${isToday ? 'text-[#111111]' : 'text-[#1F1916]'}`}>
                        {slot.day}
                        {isToday && (
                          <span className="ml-2 text-[10px] uppercase tracking-[0.14em] text-[#CD212A] font-semibold">
                            Hoje
                          </span>
                        )}
                      </dt>
                      <dd
                        className={`tabular-price ${
                          isToday && status.isOpen
                            ? 'text-[#008C45] font-semibold'
                            : slot.isOpen
                              ? 'text-[#5A4F48] font-medium'
                              : 'text-[#CD212A] font-semibold'
                        }`}
                      >
                        {slot.hours}
                      </dd>
                    </div>
                  );
                })}
              </dl>
            </div>
          </div>

          {/* Right Column: Interactive Map + Amenities & Accessibility */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            {/* Embedded Google Map */}
            <div className="flex-1 min-h-[340px] sm:min-h-[420px] rounded-sm overflow-hidden border border-[#E5DDD0] bg-[#F3ECE1] shadow-xs relative">
              <iframe
                title="Localização da Trattoria 1958 — Rua Senador Dantas, 23, Centro, Rio de Janeiro"
                src={RESTAURANT_INFO.mapsEmbedUrl}
                className="w-full h-full min-h-[340px] sm:min-h-[420px] border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            {/* Comodidades, Acessibilidade & Reservas */}
            <div className="bg-[#F3ECE1]/80 border border-[#E5DDD0] rounded-sm p-6 sm:p-7">
              <h3 className="font-serif-editorial text-2xl font-semibold text-[#1F1916] mb-4">
                Comodidades e Informações Úteis
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {AMENITIES.map((amenity) => {
                  const Icon = amenity.icon;
                  return (
                    <div
                      key={amenity.label}
                      className="flex items-start gap-3.5 bg-[#FFFFFF] border border-[#E5DDD0]/90 rounded-sm p-4"
                    >
                      <div className="w-9 h-9 rounded-full bg-[#FBF8F3] border border-[#CD212A]/50 flex items-center justify-center shrink-0 text-[#CD212A]">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-medium text-sm text-[#1F1916]">{amenity.label}</p>
                        <p className="text-xs text-[#5A4F48] mt-0.5 leading-relaxed">
                          {amenity.detail}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
