import React from 'react';
import { useRestaurantStatus } from '../hooks/useRestaurantStatus';

interface OpenStatusBadgeProps {
  variant?: 'header' | 'hero' | 'panel' | 'footer';
}

export const OpenStatusBadge: React.FC<OpenStatusBadgeProps> = ({ variant = 'panel' }) => {
  const status = useRestaurantStatus();

  const tone = status.isOpen
    ? status.isClosingSoon
      ? 'soon'
      : 'open'
    : status.isOpeningSoon
      ? 'soon'
      : 'closed';

  const dotClass =
    tone === 'open'
      ? 'bg-[#008C45] shadow-[0_0_0_4px_rgba(0,140,69,0.18)]'
      : tone === 'soon'
        ? 'bg-[#C4A35A] shadow-[0_0_0_4px_rgba(196,163,90,0.2)]'
        : 'bg-[#CD212A] shadow-[0_0_0_4px_rgba(205,33,42,0.16)]';

  if (variant === 'hero') {
    return (
      <a
        href="#localizacao"
        className="inline-flex items-center gap-2.5 px-3.5 py-2 rounded-sm bg-black/35 border border-white/20 backdrop-blur-xs text-[#FBF8F3]"
      >
        <span className="relative flex h-2.5 w-2.5">
          {tone === 'open' && (
            <span className="absolute inline-flex h-full w-full rounded-full bg-[#008C45] animate-ping opacity-70" />
          )}
          <span className={`relative inline-flex h-2.5 w-2.5 rounded-full ${dotClass.split(' ')[0]}`} />
        </span>
        <span className="text-sm">
          <strong className="font-semibold">{status.label}</strong>
          <span className="text-white/75"> · {status.detail}</span>
        </span>
      </a>
    );
  }

  if (variant === 'footer') {
    return (
      <div className="inline-flex items-center gap-2 text-xs">
        <span className={`h-2 w-2 rounded-full ${dotClass.split(' ')[0]}`} />
        <span className="text-white">
          {status.label} — {status.detail}
        </span>
      </div>
    );
  }

  const panelTone =
    tone === 'open'
      ? 'bg-[#008C45]/10 border-[#008C45]/30 text-[#0F4D2C]'
      : tone === 'soon'
        ? 'bg-[#C4A35A]/12 border-[#C4A35A]/40 text-[#6B5420]'
        : 'bg-[#CD212A]/8 border-[#CD212A]/25 text-[#8A1218]';

  return (
    <div className={`flex items-start gap-3 rounded-sm border px-4 py-3.5 ${panelTone}`}>
      <span className="relative mt-1.5 flex h-2.5 w-2.5 shrink-0">
        {tone === 'open' && (
          <span className="absolute inline-flex h-full w-full rounded-full bg-[#008C45] animate-ping opacity-70" />
        )}
        <span className={`relative inline-flex h-2.5 w-2.5 rounded-full ${dotClass.split(' ')[0]}`} />
      </span>
      <div>
        <p className="font-semibold text-sm leading-tight">{status.label}</p>
        <p className="text-xs mt-0.5 opacity-80 capitalize">{status.detail}</p>
      </div>
    </div>
  );
};

export const HeaderOpenStatus: React.FC<{ light?: boolean }> = ({ light = false }) => {
  const status = useRestaurantStatus();
  const tone = status.isOpen ? 'open' : status.isOpeningSoon || status.isClosingSoon ? 'soon' : 'closed';
  const color =
    tone === 'open' ? 'bg-[#008C45]' : tone === 'soon' ? 'bg-[#C4A35A]' : 'bg-[#CD212A]';

  return (
    <a
      href="#localizacao"
      title={`${status.label} — ${status.detail}`}
      className={`inline-flex items-center gap-2 px-2.5 py-1.5 rounded-sm text-[11px] font-semibold tracking-[0.06em] uppercase ${
        light ? 'text-white/95' : 'text-[#111111]'
      }`}
    >
      <span className="relative flex h-2 w-2">
        {status.isOpen && (
          <span className={`absolute inline-flex h-full w-full rounded-full ${color} animate-ping opacity-60`} />
        )}
        <span className={`relative inline-flex h-2 w-2 rounded-full ${color}`} />
      </span>
      <span>{status.isOpen ? 'Aberto' : 'Fechado'}</span>
    </a>
  );
};
