import React from 'react';
import { MapPin, Phone, Clock, UtensilsCrossed, Navigation } from 'lucide-react';
import { FloralDivider } from './BotanicalOrnaments';
import { Logo, TricolorBar } from './Logo';
import { OpenStatusBadge } from './OpenStatusBadge';
import { useRestaurantStatus } from '../hooks/useRestaurantStatus';
import { RESTAURANT_INFO, OPENING_HOURS } from '../data/menuData';

const FOOTER_NAV = [
  { label: 'Início', href: '#inicio' },
  { label: 'Nossa história', href: '#historia' },
  { label: 'Cardápio', href: '#cardapio' },
  { label: 'Galeria', href: '#galeria' },
  { label: 'Avaliações', href: '#avaliacoes' },
  { label: 'Localização', href: '#localizacao' },
  { label: 'Reservar uma mesa', href: '#reservas' },
];

export const Footer: React.FC = () => {
  const status = useRestaurantStatus();

  return (
    <footer className="bg-[#111111] text-[#EDE5D8]">
      <TricolorBar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 pt-16 sm:pt-20 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-14 border-b border-white/10">
          <div className="lg:col-span-4 space-y-5">
            <Logo variant="light" size="md" />
            <p className="font-serif-editorial italic text-xl text-white leading-relaxed">
              “Uma tradição italiana no coração do Rio de Janeiro.”
            </p>
            <p className="text-xs sm:text-sm text-[#EDE5D8]/75 leading-relaxed">
              Fundada na década de 1950, a Trattoria 1958 celebra a gastronomia italiana clássica com pizzas artesanais, massas frescas, risotos e hospitalidade acolhedora.
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <a
                href="#cardapio"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-sm bg-[#CD212A] hover:bg-[#A81A22] text-white text-xs font-medium transition-colors"
              >
                <UtensilsCrossed className="w-3.5 h-3.5" />
                <span>Ver Cardápio</span>
              </a>
              <a
                href="#localizacao"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-sm bg-transparent hover:bg-white/10 text-white text-xs font-medium border border-white/25 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Como Chegar</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-4">
            <h3 className="font-serif-editorial text-xl font-medium text-white tracking-wide">
              Navegação
            </h3>
            <ul className="space-y-2.5 text-sm">
              {FOOTER_NAV.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-[#EDE5D8]/80 hover:text-white transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-3 space-y-4">
            <h3 className="font-serif-editorial text-xl font-medium text-white tracking-wide">
              Contato & Localização
            </h3>
            <div className="space-y-3.5 text-sm text-[#EDE5D8]/85">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#CD212A] shrink-0 mt-1" />
                <address className="not-italic leading-relaxed">
                  {RESTAURANT_INFO.addressLine1}
                  <br />
                  {RESTAURANT_INFO.addressLine2}
                  <br />
                  {RESTAURANT_INFO.cep}
                </address>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#CD212A] shrink-0" />
                <a
                  href={RESTAURANT_INFO.phoneHref}
                  className="hover:text-white transition-colors font-medium"
                >
                  {RESTAURANT_INFO.phoneDisplay}
                </a>
              </div>

              <div className="pt-1">
                <a
                  href={RESTAURANT_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs uppercase tracking-[0.18em] text-white hover:underline underline-offset-4"
                >
                  Abrir no Google Maps →
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3 space-y-4">
            <h3 className="font-serif-editorial text-xl font-medium text-white tracking-wide flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#CD212A]" />
              <span>Funcionamento</span>
            </h3>
            <OpenStatusBadge variant="footer" />
            <ul className="space-y-2 text-xs sm:text-[13px] text-[#EDE5D8]/85">
              {OPENING_HOURS.map((slot, index) => (
                <li key={slot.day} className="flex justify-between gap-3">
                  <span className={index === status.hoursIndex ? 'text-white font-medium' : ''}>
                    {slot.day}
                    {index === status.hoursIndex ? ' · hoje' : ''}
                  </span>
                  <span
                    className={`tabular-price ${
                      index === status.hoursIndex && status.isOpen
                        ? 'text-[#008C45] font-semibold'
                        : slot.isOpen
                          ? 'text-white'
                          : 'text-[#CD212A] font-medium'
                    }`}
                  >
                    {slot.hours}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-10 text-center space-y-6">
          <FloralDivider light />
          <Logo variant="light" size="lg" />
          <p className="text-xs text-[#EDE5D8]/60">
            © {new Date().getFullYear()} Trattoria 1958 • Rua Senador Dantas, 23 — Loja B, Centro, Rio de Janeiro — RJ. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};
