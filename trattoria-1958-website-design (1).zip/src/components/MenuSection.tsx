import React, { useState, useMemo } from 'react';
import { Search, X, Sparkles } from 'lucide-react';
import { MENU_CATEGORIES, MenuCategory, MenuItem } from '../data/menuData';
import { FloralDivider } from './BotanicalOrnaments';
import { AddToCartControls, ModalAddToCart } from './AddToCartControls';
import { Reveal } from './Reveal';

export const MenuSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeDish, setActiveDish] = useState<{ item: MenuItem; category: MenuCategory } | null>(null);

  const normalizedQuery = searchQuery.trim().toLowerCase();

  const filteredCategories = useMemo(() => {
    return MENU_CATEGORIES.filter((cat) => selectedCategory === 'all' || cat.id === selectedCategory)
      .map((cat) => {
        if (!normalizedQuery) return cat;
        const matchingItems = cat.items.filter(
          (item) =>
            item.name.toLowerCase().includes(normalizedQuery) ||
            (item.description && item.description.toLowerCase().includes(normalizedQuery)) ||
            cat.title.toLowerCase().includes(normalizedQuery)
        );
        return { ...cat, items: matchingItems };
      })
      .filter((cat) => cat.items.length > 0);
  }, [selectedCategory, normalizedQuery]);

  const totalVisibleDishes = useMemo(
    () => filteredCategories.reduce((acc, cat) => acc + cat.items.length, 0),
    [filteredCategories]
  );

  return (
    <section
      id="cardapio"
      className="py-20 sm:py-28 lg:py-32 bg-[#F3ECE1]/65 border-y border-[#E5DDD0]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Section Editorial Header */}
        <Reveal className="max-w-3xl mx-auto text-center space-y-4 mb-12">
          <span className="inline-block text-xs font-medium uppercase tracking-[0.24em] text-[#CD212A]">
            Il Nostro Menù
          </span>
          <h2 className="font-serif-editorial text-3xl sm:text-5xl lg:text-[54px] font-medium text-[#1F1916] leading-[1.1]">
            Cardápio Completo
          </h2>
          <p className="text-sm sm:text-base text-[#5A4F48] max-w-2xl mx-auto leading-relaxed">
            Escolha os pratos, adicione ao pedido e finalize pelo WhatsApp (21) 2220-2783 — a mensagem já sai completa com itens, endereço, telefone e referência.
          </p>
          <FloralDivider className="pt-2" />
        </Reveal>

        {/* Search & Category Filter Controls */}
        <div className="bg-[#FFFFFF] border border-[#E5DDD0] rounded-sm p-4 sm:p-6 shadow-[0_8px_30px_rgba(31,25,22,0.04)] mb-12">
          {/* Search Input Row */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 mb-5 border-b border-[#E5DDD0]/80">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-[#5C5854] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar prato ou ingrediente (ex: burrata, parma, filé...)"
                aria-label="Buscar no cardápio"
                className="w-full pl-10 pr-9 py-2.5 text-sm bg-[#FBF8F3] border border-[#E5DDD0] rounded-sm text-[#1F1916] placeholder:text-[#5A4F48]/70 focus:outline-none focus:border-[#CD212A] transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  aria-label="Limpar busca"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5A4F48] hover:text-[#1F1916]"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="text-xs text-[#5A4F48] flex items-center gap-2">
              <span>
                Exibindo <strong className="font-semibold text-[#1F1916]">{totalVisibleDishes}</strong>{' '}
                {totalVisibleDishes === 1 ? 'opção' : 'opções'}
              </span>
              {(selectedCategory !== 'all' || normalizedQuery) && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('all');
                    setSearchQuery('');
                  }}
                  className="text-[#CD212A] underline underline-offset-2 font-medium hover:text-[#A81A22] ml-2"
                >
                  Ver tudo
                </button>
              )}
            </div>
          </div>

          {/* Category Tabs */}
          <div
            role="tablist"
            aria-label="Categorias do cardápio"
            className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1"
          >
            <button
              type="button"
              role="tab"
              aria-selected={selectedCategory === 'all'}
              onClick={() => setSelectedCategory('all')}
              className={`shrink-0 px-4 py-2 rounded-sm text-xs sm:text-[13px] font-medium tracking-[0.02em] transition-all border ${
                selectedCategory === 'all'
                  ? 'bg-[#CD212A] text-[#FBF8F3] border-[#CD212A] shadow-xs'
                  : 'bg-[#FBF8F3] text-[#1F1916] border-[#E5DDD0] hover:border-[#CD212A] hover:text-[#CD212A]'
              }`}
            >
              Todas as Categorias
            </button>

            {MENU_CATEGORIES.map((category) => {
              const isActive = selectedCategory === category.id;
              return (
                <button
                  key={category.id}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`shrink-0 px-4 py-2 rounded-sm text-xs sm:text-[13px] font-medium tracking-[0.02em] transition-all border ${
                    isActive
                      ? 'bg-[#CD212A] text-[#FBF8F3] border-[#CD212A] shadow-xs'
                      : 'bg-[#FBF8F3] text-[#1F1916] border-[#E5DDD0] hover:border-[#CD212A] hover:text-[#CD212A]'
                  }`}
                >
                  <span>{category.title}</span>
                  <span
                    className={`ml-1.5 text-[11px] ${
                      isActive ? 'text-[#FFFFFF]' : 'text-[#5A4F48]'
                    }`}
                  >
                    ({category.items.length})
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Empty Search State */}
        {filteredCategories.length === 0 ? (
          <div className="bg-[#FFFFFF] border border-[#E5DDD0] rounded-sm p-12 text-center space-y-4">
            <p className="font-serif-editorial text-2xl text-[#1F1916]">
              Nenhum prato encontrado para “{searchQuery}”.
            </p>
            <p className="text-sm text-[#5A4F48]">
              Tente buscar por outro ingrediente ou explore todas as categorias do nosso cardápio.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="inline-flex items-center px-5 py-2.5 rounded-sm bg-[#CD212A] text-[#FBF8F3] text-sm font-medium hover:bg-[#A81A22] transition-colors"
            >
              Restaurar cardápio completo
            </button>
          </div>
        ) : (
          /* Categories List */
          <div className="space-y-16 sm:space-y-20">
            {filteredCategories.map((category) => (
              <div key={category.id} id={`cat-${category.id}`} className="scroll-mt-28">
                {/* Category Editorial Banner */}
                <div className="relative rounded-sm overflow-hidden bg-[#1F1916] border border-[#E5DDD0] mb-8 shadow-sm">
                  <img
                    src={category.bannerImage}
                    alt={category.title}
                    className="w-full h-40 sm:h-48 object-cover object-center opacity-55"
                    loading="lazy"
                  />
                  <div
                    className="absolute inset-0 bg-gradient-to-r from-[#1A0E0C]/92 via-[#1A0E0C]/75 to-[#1A0E0C]/45"
                    aria-hidden="true"
                  />
                  <div className="relative z-10 px-6 sm:px-10 py-7 sm:py-9 flex flex-col md:flex-row md:items-end justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2.5 mb-1.5">
                        <span className="h-[1px] w-6 bg-[#FFFFFF]" />
                        <span className="text-[11px] uppercase tracking-[0.24em] text-[#FFFFFF]">
                          Trattoria 1958
                        </span>
                      </div>
                      <h3 className="font-serif-editorial text-3xl sm:text-4xl font-medium text-[#FBF8F3]">
                        {category.title}
                      </h3>
                      {category.subtitle && (
                        <p className="text-xs sm:text-sm text-[#EDE5D8]/85 mt-1 max-w-2xl">
                          {category.subtitle}
                        </p>
                      )}
                    </div>

                    {category.note && (
                      <div className="inline-flex items-center gap-2 px-4 py-2 rounded-sm bg-[#CD212A]/90 border border-[#FFFFFF]/50 text-[#FBF8F3] text-xs font-medium self-start md:self-auto">
                        <Sparkles className="w-3.5 h-3.5 text-[#FFFFFF] shrink-0" />
                        <span>{category.note}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Dish Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
                  {category.items.map((item) => {
                    const isPizza = Boolean(item.priceIndividual && item.priceLarge);

                    return (
                      <article
                        key={item.id}
                        onClick={() => setActiveDish({ item, category })}
                        className="group cursor-pointer card-lift bg-[#FFFFFF] border border-[#E5DDD0] hover:border-[#CD212A] rounded-sm p-5 sm:p-6 flex flex-col sm:flex-row gap-5 justify-between"
                      >
                        {/* Optional Dish Photograph */}
                        {item.image && (
                          <div className="w-full sm:w-36 h-44 sm:h-32 shrink-0 rounded-sm overflow-hidden bg-[#F3ECE1] border border-[#E5DDD0]/60">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                              loading="lazy"
                            />
                          </div>
                        )}

                        {/* Dish Info & Pricing */}
                        <div className="flex-1 flex flex-col justify-between min-w-0">
                          <div>
                            <div className="flex items-start justify-between gap-3">
                              <h4 className="font-serif-editorial text-xl sm:text-2xl font-semibold text-[#1F1916] group-hover:text-[#CD212A] transition-colors leading-snug">
                                {item.name}
                              </h4>

                              {/* Single Price Badge */}
                              {!isPizza && item.price && (
                                <span className="shrink-0 font-serif-editorial text-xl sm:text-[22px] font-semibold text-[#CD212A] tabular-price">
                                  {item.price}
                                </span>
                              )}
                            </div>

                            {item.featured && (
                              <span className="inline-block mt-1 text-[10px] uppercase tracking-[0.2em] font-semibold text-[#5C5854]">
                                Especialidade da Casa
                              </span>
                            )}

                            {item.description && (
                              <p className="text-sm text-[#5A4F48] leading-relaxed mt-2">
                                {item.description}
                              </p>
                            )}
                          </div>

                          {/* Dual Pricing for Pizzas (Individual | Grande) */}
                          {isPizza && (
                            <div className="mt-4 pt-3 border-t border-[#E5DDD0]/80 flex flex-wrap items-center gap-3">
                              <div className="inline-flex items-baseline gap-1.5 px-3 py-1 rounded-sm bg-[#FBF8F3] border border-[#E5DDD0]">
                                <span className="text-[11px] uppercase tracking-wider text-[#5A4F48]">
                                  Individual
                                </span>
                                <span className="font-serif-editorial text-lg font-semibold text-[#CD212A] tabular-price">
                                  {item.priceIndividual}
                                </span>
                              </div>

                              <div className="inline-flex items-baseline gap-1.5 px-3 py-1 rounded-sm bg-[#FBF8F3] border border-[#CD212A]/45">
                                <span className="text-[11px] uppercase tracking-wider text-[#5A4F48]">
                                  Grande
                                </span>
                                <span className="font-serif-editorial text-lg font-semibold text-[#CD212A] tabular-price">
                                  {item.priceLarge}
                                </span>
                              </div>
                            </div>
                          )}

                          <AddToCartControls item={item} category={category.title} compact />
                        </div>
                      </article>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dish Detail Modal */}
      {activeDish && (
        <div
          className="fixed inset-0 z-50 bg-[#140B09]/75 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setActiveDish(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-dish-title"
        >
          <div
            className="bg-[#FBF8F3] border border-[#CD212A]/60 rounded-sm max-w-xl w-full overflow-hidden shadow-2xl animate-editorial-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-56 sm:h-64 bg-[#1F1916]">
              <img
                src={activeDish.item.image || activeDish.category.bannerImage}
                alt={activeDish.item.name}
                className="w-full h-full object-cover object-center"
              />
              <div
                className="absolute inset-0 bg-gradient-to-t from-[#140B09]/80 via-transparent to-black/30"
                aria-hidden="true"
              />
              <button
                type="button"
                onClick={() => setActiveDish(null)}
                aria-label="Fechar detalhes do prato"
                className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[#1F1916]/75 text-[#FBF8F3] hover:bg-[#CD212A] flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="absolute bottom-4 left-6 text-xs uppercase tracking-[0.22em] text-[#FFFFFF] font-medium">
                {activeDish.category.title}
              </span>
            </div>

            <div className="p-6 sm:p-8 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
                <h3
                  id="modal-dish-title"
                  className="font-serif-editorial text-3xl font-semibold text-[#1F1916]"
                >
                  {activeDish.item.name}
                </h3>

                {activeDish.item.price && (
                  <span className="font-serif-editorial text-2xl font-semibold text-[#CD212A] tabular-price">
                    {activeDish.item.price}
                  </span>
                )}
              </div>

              {activeDish.item.priceIndividual && activeDish.item.priceLarge && (
                <div className="flex flex-wrap gap-3">
                  <span className="px-3.5 py-1.5 rounded-sm bg-[#FFFFFF] border border-[#E5DDD0] text-sm">
                    Individual:{' '}
                    <strong className="font-serif-editorial text-lg text-[#CD212A] tabular-price">
                      {activeDish.item.priceIndividual}
                    </strong>
                  </span>
                  <span className="px-3.5 py-1.5 rounded-sm bg-[#FFFFFF] border border-[#CD212A]/60 text-sm">
                    Grande:{' '}
                    <strong className="font-serif-editorial text-lg text-[#CD212A] tabular-price">
                      {activeDish.item.priceLarge}
                    </strong>
                  </span>
                </div>
              )}

              {activeDish.item.description && (
                <p className="text-base text-[#5A4F48] leading-relaxed">
                  {activeDish.item.description}
                </p>
              )}

              <div className="pt-4 border-t border-[#E5DDD0]">
                <ModalAddToCart
                  item={activeDish.item}
                  category={activeDish.category.title}
                  onAdded={() => setActiveDish(null)}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
