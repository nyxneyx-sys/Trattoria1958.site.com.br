import React from 'react';
import { FloralDivider, CornerFlourish } from './BotanicalOrnaments';
import { Reveal } from './Reveal';

export const HistorySection: React.FC = () => {
  return (
    <section
      id="historia"
      className="relative py-20 sm:py-28 lg:py-32 bg-[#FBF8F3] overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Editorial Visual Composition */}
          <Reveal className="lg:col-span-6 relative" direction="left">
            <div className="relative p-3 sm:p-5 bg-[#FFFFFF] border border-[#E5DDD0] shadow-[0_20px_50px_rgba(31,25,22,0.06)]">
              <CornerFlourish className="absolute top-2 left-2 z-10" />
              <CornerFlourish className="absolute top-2 right-2 z-10 rotate-90" />
              <CornerFlourish className="absolute bottom-2 left-2 z-10 -rotate-90" />
              <CornerFlourish className="absolute bottom-2 right-2 z-10 rotate-180" />

              <div className="relative aspect-[4/3] overflow-hidden bg-[#F3ECE1]">
                <img
                  src="/images/heritage-table.jpg"
                  alt="Ingredientes clássicos da gastronomia italiana: massas artesanais, Parmigiano-Reggiano, manjericão e azeite extra virgem"
                  className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-[1.03]"
                  loading="lazy"
                />
              </div>

              {/* Editorial Caption Strip */}
              <div className="pt-4 pb-1 px-2 flex items-center justify-between text-xs text-[#5A4F48]">
                <span className="font-serif-editorial italic text-base text-[#1F1916]">
                  Essência da cozinha italiana desde a década de 1950
                </span>
                <span className="uppercase tracking-[0.2em] text-[10px] font-medium text-[#5C5854]">
                  Trattoria 1958
                </span>
              </div>
            </div>

            {/* Floating Heritage Seal */}
            <div className="hidden sm:flex flex-col items-center justify-center w-28 h-28 rounded-full bg-[#111111] text-white shadow-xl absolute -bottom-6 -right-4 lg:-right-6 select-none overflow-hidden">
              <span className="absolute top-0 inset-x-0 h-[4px] flex">
                <span className="flex-1 bg-[#008C45]" />
                <span className="flex-1 bg-white" />
                <span className="flex-1 bg-[#CD212A]" />
              </span>
              <span className="text-[9px] uppercase tracking-[0.24em] text-white/80 mt-1">Desde</span>
              <span className="font-logo text-2xl font-semibold leading-none my-0.5 tracking-widest">
                1958
              </span>
              <span className="text-[8px] uppercase tracking-[0.18em] text-white/70">Rio de Janeiro</span>
              <span className="absolute bottom-0 inset-x-0 h-[4px] flex">
                <span className="flex-1 bg-[#008C45]" />
                <span className="flex-1 bg-white" />
                <span className="flex-1 bg-[#CD212A]" />
              </span>
            </div>
          </Reveal>

          <Reveal className="lg:col-span-6 space-y-6" direction="right" delay={120}>
            <div className="space-y-3">
              <span className="inline-block text-xs font-medium uppercase tracking-[0.24em] text-[#CD212A]">
                Nossa História
              </span>
              <h2 className="font-serif-editorial text-3xl sm:text-4xl lg:text-5xl font-medium text-[#1F1916] leading-[1.12]">
                Uma história de tradição italiana.
              </h2>
            </div>

            <FloralDivider className="justify-start! py-1" />

            <div className="space-y-5 text-base sm:text-[17px] text-[#5A4F48] leading-[1.8] font-normal">
              <p className="first-letter:font-serif-editorial first-letter:text-5xl first-letter:font-semibold first-letter:text-[#CD212A] first-letter:float-left first-letter:mr-3 first-letter:leading-[0.9]">
                Tradicionalíssimo reduto italiano fundado na década de 1950, a Trattoria 1958 preserva a essência da gastronomia italiana, oferecendo uma experiência especial para quem aprecia boas pizzas, massas frescas e pratos preparados com dedicação.
              </p>

              <p>
                Localizada no coração comercial do Rio de Janeiro, nossa casa combina tradição, sabores marcantes e um ambiente acolhedor.
              </p>
            </div>

            {/* Three Subtle Culinary Pillars */}
            <div className="pt-6 mt-6 border-t border-[#E5DDD0] grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div>
                <p className="font-serif-editorial text-xl font-semibold text-[#1F1916]">
                  Forno a Lenha
                </p>
                <p className="text-xs sm:text-sm text-[#5A4F48] mt-1 leading-relaxed">
                  Pizzas de massa fina e preparos gratinados na tradição clássica.
                </p>
              </div>

              <div>
                <p className="font-serif-editorial text-xl font-semibold text-[#1F1916]">
                  Massas & Risotos
                </p>
                <p className="text-xs sm:text-sm text-[#5A4F48] mt-1 leading-relaxed">
                  Receitas artesanais preparadas diariamente com ingredientes selecionados.
                </p>
              </div>

              <div>
                <p className="font-serif-editorial text-xl font-semibold text-[#1F1916]">
                  Centro do Rio
                </p>
                <p className="text-xs sm:text-sm text-[#5A4F48] mt-1 leading-relaxed">
                  Hospitalidade atenciosa na Rua Senador Dantas, coração histórico da cidade.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};
