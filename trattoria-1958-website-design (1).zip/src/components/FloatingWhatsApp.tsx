import React from 'react';
import { MessageCircle } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menuData';
import { useCart } from '../context/CartContext';

export const FloatingWhatsApp: React.FC = () => {
  const { itemCount, openCart } = useCart();

  if (itemCount > 0) {
    return (
      <button
        type="button"
        onClick={openCart}
        className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-[#25D366] hover:bg-[#1ebe5d] text-white text-sm font-medium animate-whatsapp-pulse btn-lift"
        aria-label="Finalizar pedido no WhatsApp"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="hidden sm:inline">Finalizar no WhatsApp</span>
        <span className="sm:hidden">{itemCount}</span>
      </button>
    );
  }

  const intro = `Olá, ${RESTAURANT_INFO.name}! Gostaria de informações sobre o cardápio e reservas.`;
  const href = `${RESTAURANT_INFO.whatsappUrl}?text=${encodeURIComponent(intro)}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-[#25D366] hover:bg-[#1ebe5d] text-white text-sm font-medium animate-whatsapp-pulse btn-lift"
      aria-label="Falar no WhatsApp"
    >
      <MessageCircle className="w-5 h-5" />
      <span className="hidden sm:inline">WhatsApp {RESTAURANT_INFO.whatsappDisplay}</span>
    </a>
  );
};
