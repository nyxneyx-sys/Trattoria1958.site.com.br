import React from 'react';

interface LogoProps {
  variant?: 'dark' | 'light';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_MAP = {
  sm: {
    eyebrow: 'text-[7px] sm:text-[8px] tracking-[0.42em]',
    word: 'text-[17px] sm:text-[20px] tracking-[0.12em]',
    year: 'text-[8px] sm:text-[9px] tracking-[0.38em]',
    flag: 'w-[11px] h-[14px] sm:w-[13px] sm:h-[16px] mx-[1px]',
    line: 'w-5 sm:w-6',
    gap: 'gap-[3px]',
  },
  md: {
    eyebrow: 'text-[8px] sm:text-[9px] tracking-[0.44em]',
    word: 'text-[22px] sm:text-[26px] tracking-[0.14em]',
    year: 'text-[9px] sm:text-[10px] tracking-[0.4em]',
    flag: 'w-[14px] h-[18px] sm:w-[16px] sm:h-[21px] mx-[1.5px]',
    line: 'w-7 sm:w-8',
    gap: 'gap-[4px]',
  },
  lg: {
    eyebrow: 'text-[10px] tracking-[0.46em]',
    word: 'text-[34px] sm:text-[40px] tracking-[0.16em]',
    year: 'text-[12px] tracking-[0.42em]',
    flag: 'w-[22px] h-[28px] sm:w-[26px] sm:h-[33px] mx-[2px]',
    line: 'w-10',
    gap: 'gap-[6px]',
  },
  xl: {
    eyebrow: 'text-[11px] sm:text-[13px] tracking-[0.5em]',
    word: 'text-[42px] sm:text-[56px] tracking-[0.18em]',
    year: 'text-[13px] sm:text-[15px] tracking-[0.46em]',
    flag: 'w-[28px] h-[36px] sm:w-[36px] sm:h-[46px] mx-[3px]',
    line: 'w-12 sm:w-16',
    gap: 'gap-[8px]',
  },
};

/** Italian flag oval that replaces the letter O in TRATTORIA */
export const ItalianFlagO: React.FC<{ className?: string }> = ({ className = '' }) => (
  <span
    className={`relative inline-block overflow-hidden rounded-[3px] align-middle shrink-0 ${className}`}
    aria-hidden="true"
  >
    <span className="absolute inset-0 flex">
      <span className="flex-1 bg-[#008C45]" />
      <span className="flex-1 bg-[#F5F5F5]" />
      <span className="flex-1 bg-[#CD212A]" />
    </span>
  </span>
);

export const Logo: React.FC<LogoProps> = ({
  variant = 'dark',
  size = 'md',
  className = '',
}) => {
  const s = SIZE_MAP[size];
  const color = variant === 'light' ? 'text-white' : 'text-[#111111]';
  const lineColor = variant === 'light' ? 'bg-white/80' : 'bg-[#111111]';

  return (
    <div
      className={`inline-flex flex-col items-center select-none leading-none ${color} ${className}`}
      aria-label="Trattoria 1958 — Ristorante & Pizzeria"
    >
      <span
        className={`font-logo font-medium uppercase ${s.eyebrow} opacity-80`}
      >
        Ristorante &amp; Pizzeria
      </span>

      <div className={`flex items-center justify-center ${s.gap} mt-[3px]`}>
        <span className={`font-logo font-semibold uppercase ${s.word}`}>TRATT</span>
        <ItalianFlagO className={s.flag} />
        <span className={`font-logo font-semibold uppercase ${s.word}`}>RIA</span>
      </div>

      <div className="flex items-center justify-center gap-2 mt-[5px]">
        <span className={`h-px ${s.line} ${lineColor}`} />
        <span className={`font-logo font-medium ${s.year}`}>1958</span>
        <span className={`h-px ${s.line} ${lineColor}`} />
      </div>
    </div>
  );
};

export const TricolorBar: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`flex h-[3px] w-full overflow-hidden ${className}`} aria-hidden="true">
    <span className="flex-1 bg-[#008C45]" />
    <span className="flex-1 bg-[#F5F5F5]" />
    <span className="flex-1 bg-[#CD212A]" />
  </div>
);
