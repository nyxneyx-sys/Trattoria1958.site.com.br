import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, CalendarCheck } from 'lucide-react';
import { Logo, TricolorBar } from './Logo';
import { CartButton } from './CartDrawer';
import { HeaderOpenStatus, OpenStatusBadge } from './OpenStatusBadge';
import { RESTAURANT_INFO } from '../data/menuData';

const NAV_LINKS = [
  { label: 'Início', href: '#inicio' },
  { label: 'Nossa história', href: '#historia' },
  { label: 'Cardápio', href: '#cardapio' },
  { label: 'Galeria', href: '#galeria' },
  { label: 'Avaliações', href: '#avaliacoes' },
  { label: 'Localização', href: '#localizacao' },
];

export const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const handleNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled || mobileMenuOpen
          ? 'bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#E6E1D8] py-2.5 shadow-[0_4px_24px_rgba(17,17,17,0.06)]'
          : 'bg-gradient-to-b from-black/75 via-black/40 to-transparent py-4'
      }`}
    >
      <TricolorBar className={scrolled ? 'opacity-100' : 'opacity-80'} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 flex items-center justify-between gap-4 pt-2">
        <a
          href="#inicio"
          aria-label="Trattoria 1958 — Voltar ao início"
          className="focus:outline-none focus-visible:ring-2 focus-visible:ring-[#CD212A] rounded-sm"
        >
          <Logo
            variant={scrolled || mobileMenuOpen ? 'dark' : 'light'}
            size={scrolled ? 'sm' : 'md'}
          />
        </a>

        <nav aria-label="Navegação principal" className="hidden lg:flex items-center gap-7 xl:gap-8">
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={`text-[13.5px] font-medium tracking-[0.04em] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-px after:bg-[#CD212A] hover:after:w-full after:transition-all after:duration-300 ${
                scrolled
                  ? 'text-[#111111] hover:text-[#CD212A]'
                  : 'text-white/95 hover:text-white'
              }`}
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-3">
          <HeaderOpenStatus light={!scrolled && !mobileMenuOpen} />
          <CartButton light={!scrolled && !mobileMenuOpen} />
          <a
            href="#reservas"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-sm text-sm font-medium tracking-[0.04em] transition-all duration-200 bg-[#CD212A] text-white hover:bg-[#A81A22]"
          >
            <CalendarCheck className="w-4 h-4" />
            <span>Reservar uma mesa</span>
          </a>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <HeaderOpenStatus light={!scrolled && !mobileMenuOpen} />
          <CartButton light={!scrolled && !mobileMenuOpen} />
          <a
            href="#reservas"
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-sm text-xs font-medium bg-[#CD212A] text-white hover:bg-[#A81A22]"
          >
            Reservar uma mesa
          </a>
          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            className={`p-2.5 rounded-sm border transition-colors ${
              scrolled || mobileMenuOpen
                ? 'text-[#111111] border-[#E6E1D8] bg-white/80 hover:bg-[#F3EEE7]'
                : 'text-white border-white/25 bg-black/40 hover:bg-black/60'
            }`}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[92px] bottom-0 bg-[#FAF8F5] border-t border-[#E6E1D8] z-40 overflow-y-auto animate-editorial-in">
          <div className="max-w-lg mx-auto px-6 py-8 flex flex-col justify-between min-h-full">
            <nav aria-label="Menu mobile" className="flex flex-col divide-y divide-[#E6E1D8]">
              {NAV_LINKS.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={handleNavClick}
                  className="py-4 font-serif-editorial text-2xl font-medium text-[#111111] hover:text-[#CD212A] flex items-center justify-between transition-colors"
                >
                  <span>{item.label}</span>
                  <span className="text-xs font-sans-clean uppercase tracking-widest text-[#CD212A]">
                    •
                  </span>
                </a>
              ))}
            </nav>

            <div className="mt-8 pt-6 border-t border-[#E6E1D8] space-y-4">
              <div className="flex justify-center">
                <OpenStatusBadge variant="panel" />
              </div>
              <a
                href="#reservas"
                onClick={handleNavClick}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-sm bg-[#CD212A] text-white font-medium text-base hover:bg-[#A81A22] transition-colors"
              >
                <CalendarCheck className="w-4 h-4" />
                <span>Reservar uma mesa</span>
              </a>

              <a
                href={RESTAURANT_INFO.phoneHref}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-sm border border-[#111111] text-[#111111] font-medium text-sm hover:bg-[#F3EEE7] transition-colors"
              >
                <Phone className="w-4 h-4 text-[#CD212A]" />
                <span>{RESTAURANT_INFO.phoneDisplay}</span>
              </a>

              <p className="text-center text-xs text-[#5C5854] pt-1">
                {RESTAURANT_INFO.addressLine1} • {RESTAURANT_INFO.addressLine2}
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
