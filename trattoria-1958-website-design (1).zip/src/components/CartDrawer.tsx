import React, { useMemo, useState } from 'react';
import {
  X,
  Minus,
  Plus,
  Trash2,
  ShoppingBag,
  MapPin,
  Phone,
  MessageCircle,
  Copy,
  Check,
  ArrowLeft,
  Bike,
  Store,
} from 'lucide-react';
import { CheckoutDetails, formatBRL, useCart } from '../context/CartContext';
import { buildOrderWhatsAppMessage, openWhatsAppOrder } from '../utils/whatsapp';
import { RESTAURANT_INFO } from '../data/menuData';

const EMPTY_DETAILS: CheckoutDetails = {
  name: '',
  phone: '',
  fulfillment: 'entrega',
  street: '',
  number: '',
  complement: '',
  neighborhood: '',
  city: 'Rio de Janeiro — RJ',
  cep: '',
  reference: '',
  payment: 'pix',
  notes: '',
};

export const CartDrawer: React.FC = () => {
  const { items, itemCount, subtotal, isOpen, closeCart, increment, decrement, removeItem, clearCart } =
    useCart();
  const [step, setStep] = useState<'cart' | 'checkout'>('cart');
  const [details, setDetails] = useState<CheckoutDetails>(EMPTY_DETAILS);
  const [copied, setCopied] = useState(false);
  const [sent, setSent] = useState(false);

  const message = useMemo(
    () => (items.length ? buildOrderWhatsAppMessage(details, items, subtotal) : ''),
    [details, items, subtotal]
  );

  const deliveryIncomplete =
    details.fulfillment === 'entrega' &&
    (!details.street.trim() || !details.number.trim() || !details.neighborhood.trim() || !details.reference.trim());

  const canSubmit =
    Boolean(details.name.trim() && details.phone.trim()) && !deliveryIncomplete && items.length > 0;

  const update = (field: keyof CheckoutDetails, value: string) => {
    setDetails((prev) => ({ ...prev, [field]: value }));
    setSent(false);
  };

  const handleClose = () => {
    closeCart();
    setTimeout(() => {
      setStep('cart');
      setSent(false);
      setCopied(false);
    }, 250);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    openWhatsAppOrder(message);
    setSent(true);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      /* ignore */
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70]">
      <button
        type="button"
        aria-label="Fechar pedido"
        className="absolute inset-0 bg-[#111111]/60 backdrop-blur-xs animate-fade-overlay"
        onClick={handleClose}
      />

      <aside
        className="absolute right-0 top-0 h-full w-full max-w-md bg-[#FAF8F5] shadow-2xl flex flex-col animate-slide-in-right"
        role="dialog"
        aria-modal="true"
        aria-label="Seu pedido"
      >
        <header className="shrink-0 border-b border-[#E6E1D8] px-5 py-4 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            {step === 'checkout' ? (
              <button
                type="button"
                onClick={() => setStep('cart')}
                className="p-1.5 rounded-sm hover:bg-[#F3EEE7]"
                aria-label="Voltar ao pedido"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            ) : (
              <ShoppingBag className="w-5 h-5 text-[#CD212A]" />
            )}
            <div>
              <p className="font-serif-editorial text-xl font-semibold leading-none">
                {step === 'cart' ? 'Seu pedido' : 'Finalizar no WhatsApp'}
              </p>
              <p className="text-[11px] uppercase tracking-[0.16em] text-[#5C5854] mt-1">
                WhatsApp {RESTAURANT_INFO.whatsappDisplay}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-2 rounded-sm hover:bg-[#F3EEE7]"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        {step === 'cart' ? (
          <>
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
              {items.length === 0 ? (
                <div className="h-full min-h-[240px] flex flex-col items-center justify-center text-center px-6">
                  <ShoppingBag className="w-10 h-10 text-[#CD212A] mb-3" />
                  <p className="font-serif-editorial text-2xl">Seu pedido está vazio</p>
                  <p className="text-sm text-[#5C5854] mt-2">
                    Escolha os pratos no cardápio e adicione ao pedido para enviar pelo WhatsApp.
                  </p>
                  <a
                    href="#cardapio"
                    onClick={handleClose}
                    className="mt-5 inline-flex px-5 py-2.5 rounded-sm bg-[#CD212A] text-white text-sm font-medium hover:bg-[#A81A22]"
                  >
                    Ver cardápio
                  </a>
                </div>
              ) : (
                items.map((item) => (
                  <article
                    key={item.cartId}
                    className="bg-white border border-[#E6E1D8] rounded-sm p-3.5 flex gap-3"
                  >
                    {item.image && (
                      <img
                        src={item.image}
                        alt=""
                        className="w-16 h-16 object-cover rounded-sm shrink-0 bg-[#F3EEE7]"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between gap-2">
                        <div>
                          <h3 className="font-serif-editorial text-lg font-semibold leading-tight">
                            {item.name}
                          </h3>
                          {item.sizeLabel && (
                            <p className="text-[11px] uppercase tracking-wider text-[#CD212A] mt-0.5">
                              {item.sizeLabel}
                            </p>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => removeItem(item.cartId)}
                          className="text-[#5C5854] hover:text-[#CD212A] p-1"
                          aria-label={`Remover ${item.name}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="inline-flex items-center border border-[#E6E1D8] rounded-sm">
                          <button
                            type="button"
                            onClick={() => decrement(item.cartId)}
                            className="px-2 py-1 hover:bg-[#F3EEE7]"
                            aria-label="Diminuir"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-2 text-sm tabular-price min-w-[1.5rem] text-center">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => increment(item.cartId)}
                            className="px-2 py-1 hover:bg-[#F3EEE7]"
                            aria-label="Aumentar"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <span className="font-serif-editorial text-lg font-semibold text-[#CD212A] tabular-price">
                          {formatBRL(item.unitPrice * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </article>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className="shrink-0 border-t border-[#E6E1D8] bg-white p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#5C5854]">
                    {itemCount} {itemCount === 1 ? 'item' : 'itens'}
                  </span>
                  <span className="font-serif-editorial text-2xl font-semibold tabular-price">
                    {formatBRL(subtotal)}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setStep('checkout')}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-sm bg-[#CD212A] text-white font-medium hover:bg-[#A81A22] transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  Finalizar pedido no WhatsApp
                </button>
                <button
                  type="button"
                  onClick={clearCart}
                  className="w-full text-xs text-[#5C5854] hover:text-[#CD212A] underline underline-offset-4"
                >
                  Esvaziar pedido
                </button>
              </div>
            )}
          </>
        ) : (
          <form onSubmit={handleSend} className="flex-1 overflow-y-auto px-5 py-5 space-y-5">
            <p className="text-sm text-[#5C5854] leading-relaxed">
              Preencha seus dados. A mensagem completa do pedido — com itens, telefone, endereço e referência — será enviada para o WhatsApp da Trattoria 1958:{' '}
              <strong className="text-[#111111]">{RESTAURANT_INFO.whatsappDisplay}</strong>.
            </p>

            <div className="grid grid-cols-1 gap-4">
              <Field label="Nome completo *" htmlFor="order-name">
                <input
                  id="order-name"
                  required
                  value={details.name}
                  onChange={(e) => update('name', e.target.value)}
                  placeholder="Seu nome"
                  className={inputClass}
                />
              </Field>

              <Field label="Número de telefone *" htmlFor="order-phone">
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#CD212A] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="order-phone"
                    required
                    type="tel"
                    value={details.phone}
                    onChange={(e) => update('phone', e.target.value)}
                    placeholder="(21) 99999-9999"
                    className={`${inputClass} pl-10`}
                  />
                </div>
              </Field>
            </div>

            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2">Como deseja receber?</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => update('fulfillment', 'entrega')}
                  className={`flex items-center justify-center gap-2 px-3 py-3 rounded-sm border text-sm font-medium ${
                    details.fulfillment === 'entrega'
                      ? 'bg-[#CD212A] text-white border-[#CD212A]'
                      : 'bg-white border-[#E6E1D8] hover:border-[#CD212A]'
                  }`}
                >
                  <Bike className="w-4 h-4" />
                  Entrega
                </button>
                <button
                  type="button"
                  onClick={() => update('fulfillment', 'retirada')}
                  className={`flex items-center justify-center gap-2 px-3 py-3 rounded-sm border text-sm font-medium ${
                    details.fulfillment === 'retirada'
                      ? 'bg-[#CD212A] text-white border-[#CD212A]'
                      : 'bg-white border-[#E6E1D8] hover:border-[#CD212A]'
                  }`}
                >
                  <Store className="w-4 h-4" />
                  Retirada
                </button>
              </div>
            </div>

            {details.fulfillment === 'entrega' && (
              <div className="space-y-4 bg-white border border-[#E6E1D8] rounded-sm p-4">
                <p className="font-serif-editorial text-lg font-semibold flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#CD212A]" />
                  Endereço de entrega
                </p>

                <Field label="Rua / Avenida *" htmlFor="order-street">
                  <input
                    id="order-street"
                    required
                    value={details.street}
                    onChange={(e) => update('street', e.target.value)}
                    placeholder="Ex.: Rua do Ouvidor"
                    className={inputClass}
                  />
                </Field>

                <div className="grid grid-cols-3 gap-3">
                  <Field label="Número *" htmlFor="order-number" className="col-span-1">
                    <input
                      id="order-number"
                      required
                      value={details.number}
                      onChange={(e) => update('number', e.target.value)}
                      placeholder="123"
                      className={inputClass}
                    />
                  </Field>
                  <Field label="Complemento" htmlFor="order-comp" className="col-span-2">
                    <input
                      id="order-comp"
                      value={details.complement}
                      onChange={(e) => update('complement', e.target.value)}
                      placeholder="Apto, bloco, loja"
                      className={inputClass}
                    />
                  </Field>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Field label="Bairro *" htmlFor="order-bairro">
                    <input
                      id="order-bairro"
                      required
                      value={details.neighborhood}
                      onChange={(e) => update('neighborhood', e.target.value)}
                      placeholder="Centro"
                      className={inputClass}
                    />
                  </Field>
                  <Field label="CEP" htmlFor="order-cep">
                    <input
                      id="order-cep"
                      value={details.cep}
                      onChange={(e) => update('cep', e.target.value)}
                      placeholder="20031-000"
                      className={inputClass}
                    />
                  </Field>
                </div>

                <Field label="Cidade" htmlFor="order-city">
                  <input
                    id="order-city"
                    value={details.city}
                    onChange={(e) => update('city', e.target.value)}
                    className={inputClass}
                  />
                </Field>

                <Field label="Ponto de referência *" htmlFor="order-ref">
                  <input
                    id="order-ref"
                    required
                    value={details.reference}
                    onChange={(e) => update('reference', e.target.value)}
                    placeholder="Ex.: em frente à Candelária, portão azul"
                    className={inputClass}
                  />
                </Field>
              </div>
            )}

            <Field label="Forma de pagamento" htmlFor="order-pay">
              <select
                id="order-pay"
                value={details.payment}
                onChange={(e) => update('payment', e.target.value)}
                className={inputClass}
              >
                <option value="pix">PIX</option>
                <option value="dinheiro">Dinheiro</option>
                <option value="credito">Cartão de crédito</option>
                <option value="debito">Cartão de débito</option>
              </select>
            </Field>

            <Field label="Observações do pedido" htmlFor="order-notes">
              <textarea
                id="order-notes"
                rows={3}
                value={details.notes}
                onChange={(e) => update('notes', e.target.value)}
                placeholder="Ex.: sem cebola, ponto da carne, troco para R$ 100"
                className={inputClass}
              />
            </Field>

            <div className="bg-[#111111] text-white rounded-sm p-4 space-y-2">
              <p className="text-[11px] uppercase tracking-[0.18em] text-white/70">Prévia da mensagem</p>
              <pre className="text-xs whitespace-pre-wrap font-sans-clean leading-relaxed text-white/90 max-h-40 overflow-y-auto">
                {message}
              </pre>
            </div>

            {sent && (
              <p className="text-sm text-[#008C45] bg-[#008C45]/10 border border-[#008C45]/30 rounded-sm p-3">
                WhatsApp aberto com a mensagem completa. Envie a conversa para confirmar o pedido com a casa.
              </p>
            )}

            <div className="sticky bottom-0 bg-[#FAF8F5] pt-2 pb-4 space-y-2">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-[#5C5854]">Total</span>
                <span className="font-serif-editorial text-2xl font-semibold tabular-price">
                  {formatBRL(subtotal)}
                </span>
              </div>
              <button
                type="submit"
                disabled={!canSubmit}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-sm bg-[#25D366] hover:bg-[#1ebe5d] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                Enviar pedido no WhatsApp
              </button>
              <button
                type="button"
                onClick={handleCopy}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-sm border border-[#111111] text-sm font-medium hover:bg-white"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-[#008C45]" />
                    Mensagem copiada
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    Copiar mensagem completa
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </aside>
    </div>
  );
};

const inputClass =
  'w-full px-3.5 py-2.5 text-sm bg-white border border-[#E6E1D8] rounded-sm text-[#111111] focus:outline-none focus:border-[#CD212A]';

const Field: React.FC<{
  label: string;
  htmlFor: string;
  className?: string;
  children: React.ReactNode;
}> = ({ label, htmlFor, className = '', children }) => (
  <div className={className}>
    <label htmlFor={htmlFor} className="block text-xs font-semibold uppercase tracking-wider mb-1.5">
      {label}
    </label>
    {children}
  </div>
);

export const CartButton: React.FC<{ light?: boolean }> = ({ light = false }) => {
  const { itemCount, openCart } = useCart();

  return (
    <button
      type="button"
      onClick={openCart}
      aria-label={`Abrir pedido${itemCount ? `, ${itemCount} itens` : ''}`}
      className={`relative inline-flex items-center justify-center p-2.5 rounded-sm border transition-colors ${
        light
          ? 'text-white border-white/25 bg-black/40 hover:bg-black/60'
          : 'text-[#111111] border-[#E6E1D8] bg-white/80 hover:bg-[#F3EEE7]'
      }`}
    >
      <ShoppingBag className="w-5 h-5" />
      {itemCount > 0 && (
        <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#CD212A] text-white text-[10px] font-semibold flex items-center justify-center animate-badge-pop">
          {itemCount}
        </span>
      )}
    </button>
  );
};
