import { useEffect, useState } from 'react';
import { getRestaurantStatus, RestaurantStatus } from '../utils/openingHours';

export function useRestaurantStatus(): RestaurantStatus {
  const [status, setStatus] = useState<RestaurantStatus>(() => getRestaurantStatus());

  useEffect(() => {
    const tick = () => setStatus(getRestaurantStatus());
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);

  return status;
}
